package extended.gameInterface;

/**
 * Classes implementing this interface are able to deal with moves fired from the ControllerView
 * @author Wim, Mart, Bas, Jurrian
 */
public interface MoveListener {
	/**
	 * Deal with a performed move
	 * @param Move performed
	 */
	public void movePerformed(String move);
}
