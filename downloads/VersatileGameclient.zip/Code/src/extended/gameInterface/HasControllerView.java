package extended.gameInterface;


/**
 * Classes implementing this interface possess a ControllerView, this is a (JPanel) View that simultaneously functions as a controller
 * @author Wim, Mart, Bas, Jurrian
 */
public interface HasControllerView {
	/**
	 * Gets the ControllerView
	 * @return Controller View Panel
	 */
	public AbstractMoveActor getControllerView();
}
