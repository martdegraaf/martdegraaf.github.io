package extended.gameInterface;

/**
 * Abstract class for the game AI's.
 * @author Wim, Mart, Bas, Jurrian
 *
 */
public abstract class AbstractGameAI extends AbstractMoveActor {
	
	/**
	 * Compute the best move for the given player.
	 * @param player
	 */
	public abstract void getBestMove(int player);
}
