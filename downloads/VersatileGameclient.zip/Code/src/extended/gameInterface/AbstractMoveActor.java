package extended.gameInterface;

import java.util.ArrayList;
import java.util.Iterator;

import javax.swing.JPanel;

/**
 * A class that is able to send moves to moveListener classes. Used for the ControllerView and AbstractGameAI
 * @author Wim, Mart, Bas, Jurrian
 */
public class AbstractMoveActor extends JPanel {
	
	private ArrayList<MoveListener> listeners = new ArrayList<MoveListener>();
	
	/**
	 * Adds a class as listener for actions executed on the ControllerView
	 * @param MoveListener
	 */
	public void addMoveListener(MoveListener m) {
		if(!listeners.contains(m)) listeners.add(m);
	}
	
	/**
	 * Use this function to define moves that need to be broadcasted to listening classes
	 * @param move
	 */
	protected void notifyListeners(String move) {
		Iterator<MoveListener> it = listeners.iterator();
		while(it.hasNext()) {
			it.next().movePerformed(move);
		}
	}
}
