package extended.gameInterface;

import java.awt.Component;

/**
 * Extension of AbstractGameModule that implements additional features that are required clientside 
 * @author Wim, Mart, Bas, Jurrian
 */
public interface AbstractExtendedGameModule {
	
	/**
	 * Updates the view, makes the buttons clickable/enables input
	 */
	public abstract void allowPlayerMove();
	
	/**
	 * Let the AI choose a move
	 * @return Move string (ie: "1,1")
	 */
	public abstract AbstractGameAI getAI();
	
	public abstract int getPlayerInt(String player);
	
	// Everything below here are the prototypes of the functions defined in AbstractGameModule, this allows us to not have to cast back and forth
	
	public void doPlayerMove(String player, String move) throws IllegalStateException;
	
	public int getPlayerScore(String player) throws IllegalStateException;
	
	public String getMatchResultComment() throws IllegalStateException;
	
	public int getMatchStatus();
	
	public String getMoveDetails() throws IllegalStateException;
	
	public String getPlayerToMove() throws IllegalStateException;

	public int getPlayerResult(String player) throws IllegalStateException;
	
	public String getTurnMessage() throws IllegalStateException;
	
	public void start() throws IllegalStateException;
	
	/**
	 * Returns a view of this match.
	 * <p>
	 * It is a good idea for this view to be resizable.
	 * @return A view of the match
	 */
	public Component getView();

}
