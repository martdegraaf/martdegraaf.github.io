package extended.gameModules.connectfour;

import java.awt.Color;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.geom.Ellipse2D;

import javax.swing.JButton;
/**
 * Class that makes an representation of a connect four stone.
 * @author Mart, Wim, Jurrian en Bas
 *
 */
public class ConnectFourStone extends JButton {
	
	private static final long serialVersionUID = 1L;
	
	public static final Color BACKGROUND_COLOR = Color.blue.darker().darker();
	
	public ConnectFourStone() {
		setOpaque(true);
		setEnabled(false);
		setFocusable(false);
		setBorder(null);
		setForeground(BACKGROUND_COLOR);
		setBackground(BACKGROUND_COLOR);
	}
	
	public void setColor(Color c) {
		setForeground(c);
		repaint();
	}

	public void paintComponent(Graphics g) {
		   super.paintComponent(g);
		   Graphics2D g2d = (Graphics2D)g;
		   // Assume x, y, and diameter are instance variables.
		   int offset = (int) (this.getWidth() * 0.1);
		   int size = (int) (this.getWidth() * 0.8);
		   
		   //Ellipse2D.Double circle = new Ellipse2D.Double(offset, offset, size, size);
		   Color bgColor = this.getForeground();
		   g2d = (Graphics2D) g;
		   g2d.setPaint(new GradientPaint(0, 0, bgColor, size * 2.25f, size * 2.25f, Color.GRAY, false));
		   Ellipse2D.Double ellipse = new Ellipse2D.Double(offset,offset,size,size);
		   g2d.fill(ellipse);
		   
		   if(!bgColor.equals(ConnectFourControllerView.BACKGROUND_COLOR)) {
			   Color fgColor = Color.DARK_GRAY;
			   if(bgColor.equals(Color.WHITE)) {
				   fgColor = fgColor.brighter().brighter().brighter();
			   }
			   g2d.setColor(fgColor);
			   g2d.drawOval(7, 7, 32, 32);
		   }
		   g2d.setBackground(bgColor);
		}
}
