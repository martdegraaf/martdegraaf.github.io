package extended.gameModules.connectfour;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

import nl.hanze.t23i.gamemodule.extern.AbstractGameModule;

import extended.gameInterface.AbstractMoveActor;
import game.connectfour.ConnectFourGame;

/**
 * ControllerView for Connect four, a grid with 6 rows and 7 columns of buttons
 * @author Wim, Mart, Bas, Jurrian
 */
public class ConnectFourControllerView extends AbstractMoveActor implements ActionListener {
	
	private ConnectFourExtended gameModule;
	public static final Color BACKGROUND_COLOR = Color.blue.darker().darker();
	private JButton[][] buttonGrid = new JButton[7][6];
	
	private JButton turn;
	
	public ConnectFourControllerView(ConnectFourExtended gameModule) {
		this.gameModule = gameModule;
		JPanel board = new JPanel();
		board.setLayout(new GridLayout(6,7));
		
		for(int y = 0; y < buttonGrid[0].length; y++) {
			for(int x = 0; x < buttonGrid.length; x++) {
				JButton b = new ConnectFourStone();
				b.setFocusable(false);
				b.addActionListener(this);
				b.setOpaque(false);
				b.setBorder(null);
				b.setForeground(BACKGROUND_COLOR);
				b.setBackground(BACKGROUND_COLOR);
				
				JPanel tile = new JPanel();
				tile.setBackground(BACKGROUND_COLOR);
				tile.setLayout(new GridLayout(1,1));
				tile.add(b);
				tile.setBorder(BorderFactory.createLineBorder(Color.BLACK));
				
				board.add(tile);
				buttonGrid[x][y] = b;
			}
		}
		String playerOneName = gameModule.getPlayerName(ConnectFourGame.PLAYER_ONE);
		JLabel playerOneTxt = new JLabel(playerOneName, SwingConstants.CENTER);
		playerOneTxt.setOpaque(true);
		playerOneTxt.setBackground(ConnectFourStone.BACKGROUND_COLOR);
		playerOneTxt.setForeground(Color.WHITE);
		ConnectFourStone playerOneCol = new ConnectFourStone();
		playerOneCol.setColor(gameModule.getPlayerColor(ConnectFourGame.PLAYER_ONE));
		playerOneCol.setEnabled(false);
		playerOneCol.setPreferredSize(new Dimension(49, 49));
		
		String playerTwoName = gameModule.getPlayerName(ConnectFourGame.PLAYER_TWO);
		JLabel playerTwoTxt = new JLabel(playerTwoName, SwingConstants.CENTER);
		playerTwoTxt.setOpaque(true);
		playerTwoTxt.setBackground(ConnectFourStone.BACKGROUND_COLOR);
		playerTwoTxt.setForeground(Color.WHITE);
		ConnectFourStone playerTwoCol = new ConnectFourStone();
		playerTwoCol.setColor(gameModule.getPlayerColor(ConnectFourGame.PLAYER_TWO));
		playerTwoCol.setEnabled(false);
		playerTwoCol.setPreferredSize(new Dimension(49, 49));
		
		turn = new ConnectFourStone();
		turn.setEnabled(false);
		turn.setPreferredSize(new Dimension(49, 49));
		
		JPanel turnPanel = new JPanel(new BorderLayout());
		JLabel turnLabel = new JLabel("Turn: ", SwingConstants.CENTER);
		turnLabel.setOpaque(true);
		turnLabel.setBackground(ConnectFourStone.BACKGROUND_COLOR);
		turnLabel.setForeground(Color.WHITE);
		turnPanel.add(turnLabel, BorderLayout.NORTH);
		turnPanel.add(turn, BorderLayout.CENTER);
		
		JPanel playerOneColorTile = new JPanel(new BorderLayout());
		playerOneColorTile.add(playerOneTxt, BorderLayout.NORTH);
		playerOneColorTile.add(playerOneCol, BorderLayout.CENTER);
		
		JPanel playerTwoColorTile = new JPanel(new BorderLayout());
		playerTwoColorTile.add(playerTwoTxt, BorderLayout.NORTH);
		playerTwoColorTile.add(playerTwoCol, BorderLayout.CENTER);
		
		JPanel colorPanel = new JPanel();
		colorPanel.setLayout(new GridLayout(1, 2));
		colorPanel.setOpaque(true);
		colorPanel.setBackground(ConnectFourStone.BACKGROUND_COLOR);
		colorPanel.add(playerOneColorTile);
		colorPanel.add(playerTwoColorTile);
		
		//JPanel with color and turn information
		JPanel turnView = new JPanel();
		turnView.setLayout(new BorderLayout());
		
		JPanel filler = new JPanel();
		filler.setOpaque(true);
		filler.setBackground(ConnectFourStone.BACKGROUND_COLOR);
		
		turnView.add(turnPanel, BorderLayout.WEST);
		turnView.add(filler, BorderLayout.CENTER);
		turnView.add(colorPanel, BorderLayout.EAST);
		turnView.setOpaque(true);
		turnView.setBackground(ConnectFourStone.BACKGROUND_COLOR);
		turnView.setBorder(BorderFactory.createEmptyBorder(5, 5, 0, 5));
		
		board.setPreferredSize(new Dimension(350, 300));
		
		setLayout(new BorderLayout(5, 5));
		add(board, BorderLayout.PAGE_START);
		add(turnView, BorderLayout.PAGE_END);
		
		setPreferredSize(new Dimension(350, 400));
		
		
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		Object source = e.getSource();
		for(int x = 0; x < buttonGrid.length; x++) {
			for(int y = 0; y < buttonGrid[x].length; y++) {
				if(source == buttonGrid[x][y]) {
					buttonGrid[x][y].setEnabled(false);
					notifyListeners(x + "");
				}
			}
		}
	}
	
	/**
	 * Updates the view when it should
	 * @param board data
	 * @param isPlayerHuman?
	 */
	public void update(int[][] board, boolean playerIsHuman) {
		for(int x = 0; x < buttonGrid.length; x++) {
			for(int y = 0; y < buttonGrid[x].length; y++) {
				JButton b = buttonGrid[x][y]; 
				b.setEnabled(false);
				Color c;
				if(board[x][y] == ConnectFourGame.PLAYER_ONE) c = ConnectFourGame.playerOneColor;
				else if(board[x][y] == ConnectFourGame.PLAYER_TWO) c= ConnectFourGame.playerTwoColor;
				else {
					if(playerIsHuman) b.setEnabled(true);
					c = BACKGROUND_COLOR;
				}
				b.setForeground(c);
				b.repaint();
			}
		}
		if(gameModule.getMatchStatus() == AbstractGameModule.MATCH_STARTED) {
			updateTurnView();
		}
	}
	
	/**
	 * Update turnView.
	 */
	public void updateTurnView() {
		String player = gameModule.getPlayerToMove();
		
		Color color = gameModule.getCurrentPlayerColor();
		turn.setForeground(color);
		turn.setText(player);
	}
}
