package extended.gameModules.connectfour;


import java.awt.Color;

import extended.gameInterface.*;
import game.connectfour.ConnectFourGame;

/**
 * Class implementing the client-side additional functions of connect four 
 * @author Wim, Mart, Bas en Jurrian
 */
public class ConnectFourExtended extends ConnectFourGame implements HasControllerView, AbstractExtendedGameModule {
	
	private ConnectFourControllerView cview;
	private AbstractGameAI ai;
	
	/**
	 * Constructor
	 * @param playerOne name
	 * @param playerTwo name
	 */
	public ConnectFourExtended(String playerOne, String playerTwo) {
		super(playerOne, playerTwo);
		ai = new ConnectFourAI(board);
		cview = new ConnectFourControllerView(this);
		cview.update(board, false);
	}
	/**
	 * makes it able to make a move on the view
	 */
	public void allowPlayerMove() {
		cview.update(board, true);
	}
	
	@Override
	public void doPlayerMove(String player, String move){
		super.doPlayerMove(player, move);
		cview.update(board, false);
	}

	@Override
	public AbstractMoveActor getControllerView() {
		return cview;
	}

	@Override
	public AbstractGameAI getAI() {
		return ai;
	}
	
	/**
	 * Get the color of the current player.
	 * @return
	 */
	public Color getCurrentPlayerColor() {
		if(nextPlayer.equals(playerOne)) {
			return playerOneColor;
		}
		return playerTwoColor;
	}
	
	/**
	 * Get the color of a specific player.
	 * @param playerInt
	 * @return
	 */
	public Color getPlayerColor(int playerInt) {
		if(playerInt == PLAYER_ONE) {
			return playerOneColor;
		} else {
			return playerTwoColor;
		}
	}
	
	/**
	 * Get player name by player int.
	 * @param player
	 * @return String
	 */
	public String getPlayerName(int player) {
		if(player == PLAYER_ONE) {
			return playerOne;
		}
		return playerTwo;
	}

}