package extended.gameModules.connectfour;

import extended.gameInterface.AbstractGameAI;
import extended.gameModules.othello.NoAvailableMovesException;
import game.connectfour.ConnectFourGame;
import game.othello.OthelloGame;

import java.util.ArrayList;
import java.util.Iterator;

import model.Settings;

/**
 * AI for Connect Four
 * @author Mart, Wim, Bas en Jurrian
 */
public class ConnectFourAI extends AbstractGameAI implements Runnable {

	private final int DRAW = 2;				// Value representing a draw
	private final int STATE_UNKNOWN = 3;	// Value representing that the game is yet undecided
	
	private final int MAX_DEPTH;		// Value representing the depth of recursion
	private int[][] board;					// Playing field
	private int runForPlayer;
	
	public ConnectFourAI(int[][] board) {
		this.board = board;
		MAX_DEPTH = 1 + (int) (2.5 * Settings.DIFFICULTY);
	}
	
	
	/**
	 * Compute the best move available for player
	 * @param player
	 * @return best move (ie: "1,1")
	 */
	public void getBestMove(int player) {
		runForPlayer = player;
		Thread t = new Thread(this);
		t.start();
	}

	@Override
	public void run() {
		try{
			Move bestMove = bestMove(runForPlayer, MAX_DEPTH);
			notifyListeners(bestMove.toString());
		}catch(NoAvailableMovesException e){ }
	}
	
	/**
	 * Method to recursively compute the best move for a player
	 * @param player
	 * @return Best Move
	 * @throws NoAvailableMovesException 
	 */
	private Move bestMove(int player, int depth) throws NoAvailableMovesException {
		
		
		
		int opp = otherPlayer(player);
		
		Move bestMove = null;
		
		Iterator<Move> it = getLegalMoves(player);
		while(it.hasNext()) {
			Move move = it.next();
			board[move.x][move.y] = player;
			move.setValue(evaluateGame());
			
			// Recursive
			if(move.value == STATE_UNKNOWN) {
				if(depth == 0){
					move.value = estimateGame();
				}else{
					// If the value of the current move is unknown, the value of the move
					// can be evaluated by evaluating the opponent's best follow up move
					try{
						move.value = bestMove(opp, depth - 1).value;
					}catch(NoAvailableMovesException e){
						move.value = opp;
					}
				}
				
			}
			
			if(bestMove == null) {
				bestMove = move;
			}
			bestMove = betterMove(player, move, bestMove);
			// Remove our move from the board
			board[move.x][move.y] = ConnectFourGame.EMPTY;
			// No need to keep looking if we've found a winning move
			
			
			if(bestMove.value == player) break;
		}
		
		return bestMove;
	}


	/**
	 * Get the other player
	 * @param player
	 * @return other player
	 */
	private int otherPlayer(int player) {
		if(player == ConnectFourGame.PLAYER_ONE) return ConnectFourGame.PLAYER_TWO;
		return ConnectFourGame.PLAYER_ONE;
	}
	
	
	
	/**
	 * Determine if someone has won, lost, it's a draw or the game isnt over
	 * @return true/false
	 */
	private int evaluateGame() {
		if(fourOnARow(ConnectFourGame.PLAYER_ONE)) return ConnectFourGame.PLAYER_ONE;
		if(fourOnARow(ConnectFourGame.PLAYER_TWO)) return ConnectFourGame.PLAYER_TWO;
		if(boardIsFull()) return DRAW;
		return STATE_UNKNOWN;
	}
	/**
	 * 
	 * @param player
	 * @param a
	 * @param b
	 * @return
	 */
	private Move betterMove(int player, Move a, Move b){
		if(a.value > OthelloGame.PLAYER_TWO) a.value = ((OthelloGame.PLAYER_ONE + OthelloGame.PLAYER_TWO) / 2);
		if(b.value > OthelloGame.PLAYER_TWO) b.value = ((OthelloGame.PLAYER_ONE + OthelloGame.PLAYER_TWO) / 2);
		if(Math.abs(player - a.value) < Math.abs(player - b.value)) return a;
		return b;
	}
	
	
	/**
	 * Determine who is likely winning
	 * @return best double
	 */
	private double estimateGame() {
		//Strength = count 3 together * 32 + count 2 together * 4 + count 1 together
		int player1value =  (countThreeOnARow(ConnectFourGame.PLAYER_ONE) * 32) + (countTwoOnARow(ConnectFourGame.PLAYER_ONE) * 4) + countOneOnARow(ConnectFourGame.PLAYER_ONE);
		int player2value =  (countThreeOnARow(ConnectFourGame.PLAYER_TWO) * 32) + (countTwoOnARow(ConnectFourGame.PLAYER_TWO) * 4) + countOneOnARow(ConnectFourGame.PLAYER_TWO);
		double sum = player1value + player2value;
		return ConnectFourGame.PLAYER_ONE + (player2value/sum);
	}
	
	/**
	 * Simple check to check if the board is full
	 * @return true/false
	 */
	private boolean boardIsFull() {
		for(int i = 0; i < board.length; i++) {
			for(int j = 0; j < board[i].length; j++) {
				if(board[i][j] == ConnectFourGame.EMPTY) return false;
			}
		}
		return true;
	}
	
	/**
	 * Checks if a certain player has won
	 * @param player
	 * @return true/false
	 */
	private boolean fourOnARow(int playerInt){
		
		//verticaal
		for(int x = 0; x < board.length; x++){
			for(int y = 0; y < board[x].length-3;y++){
				if(board[x][y] == playerInt &&
						board[x][y+1] == playerInt &&
						board[x][y+2] == playerInt &&
						board[x][y+3] == playerInt){
					return true;
				}
			}
		}
		//horizontaal
		for(int y = 0; y < board[0].length ; y++){
			for(int x = board.length-1; x > 2;x--){
				if(board[x][y] == playerInt &&
						board[x-1][y] == playerInt &&
						board[x-2][y] == playerInt &&
						board[x-3][y] == playerInt){
					return true;
				}
			}
		}
		//diagonaal linksonder naar rechtsboven
		for(int y = 0; y < board[0].length-3 ; y++){
			for(int x = board.length-1; x > 2;x--){
				if(board[x][y] == playerInt &&
						board[x-1][y + 1] == playerInt &&
						board[x-2][y + 2] == playerInt &&
						board[x-3][y + 3] == playerInt){
					return true;
				}
			}
		}
		
		//diagonaal rechtsonder naar linksboven
		for(int x = 0; x < board.length-3 ; x++){
			for(int y = 0; y < board[x].length-3;y++){
				if(board[x][y] == playerInt &&
						board[x+1][y + 1] == playerInt &&
						board[x+2][y + 2] == playerInt &&
						board[x+3][y + 3] == playerInt){
					return true;
				}
			}
		}
		
		return false;
	}
	
	
	
	private int countThreeOnARow(int playerInt){
		int count = 0;
		//verticaal
		for(int x = board.length-1; x >= 0; x--){
			for(int y = 0; y < board[x].length-2;y++){
				if(board[x][y] == playerInt &&
						board[x][y+1] == playerInt &&
						board[x][y+2] == playerInt){
					count++;
				}
			}
		}
		//horizontaal
		for(int y = 0; y < board[0].length ; y++){
			for(int x = board.length-1; x > 1;x--){
				if(board[x][y] == playerInt &&
						board[x-1][y] == playerInt &&
						board[x-2][y] == playerInt){
					count++;
				}
			}
		}
		//diagonaal linksonder naar rechtsboven
		for(int y = 0; y < board[0].length-2 ; y++){
			for(int x = board.length-1; x > 1;x--){
				if(board[x][y] == playerInt &&
						board[x-1][y + 1] == playerInt &&
						board[x-2][y + 2] == playerInt){
					count++;
				}
			}
		}
		
		//diagonaal rechtsonder naar linksboven
		for(int x = 0; x < board.length-2 ; x++){
			for(int y = 0; y < board[x].length-2;y++){
				if(board[x][y] == playerInt &&
						board[x+1][y + 1] == playerInt &&
						board[x+2][y + 2] == playerInt){
					count++;
				}
			}
		}
		
		return count;
	}
	
	private int countTwoOnARow(int playerInt){
		int count = 0;
		//verticaal
		for(int x = board.length-1; x >= 0; x--){
			for(int y = 0; y < board[x].length-1;y++){
				if(board[x][y] == playerInt &&
						board[x][y+1] == playerInt){
					count++;
				}
			}
		}
		//horizontaal
		for(int y = 0; y < board[0].length ; y++){
			for(int x = board.length-1; x > 0;x--){
				if(board[x][y] == playerInt &&
						board[x-1][y] == playerInt){
					count++;
				}
			}
		}
		//diagonaal linksonder naar rechtsboven
		for(int y = 0; y < board[0].length-1 ; y++){
			for(int x = board.length-1; x > 0;x--){
				if(board[x][y] == playerInt &&
						board[x-1][y + 1] == playerInt){
					count++;
				}
			}
		}
		
		//diagonaal rechtsonder naar linksboven
		for(int x = 0; x < board.length-1 ; x++){
			for(int y = 0; y < board[x].length-1;y++){
				if(board[x][y] == playerInt &&
						board[x+1][y + 1] == playerInt){
					count++;
				}
			}
		}
		
		return count;
	}
	
	private int countOneOnARow(int playerInt){
		int count = 0;
		//verticaal
		for(int x = board.length-1; x >= 0; x--){
			for(int y = 0; y < board[x].length;y++){
				if(board[x][y] == playerInt){
					count++;
				}
			}
		}
		
		return count;
	}
	
	/**
	 * Function to count stones of player
	 * @param int of the player
	 * @return value of stones by this player
	 */
	public int countStones(int player){
		int count = 0;
		for(int i = 0;i<board.length;i++){
			for(int j = 0;j<board[i].length;j++){
				if(board[i][j] == player){
					count++;
				}
			}
		}
		return count;
	}
	
	
	/**
	 * Gets an iterator over all legal moves
	 * @return legal moves
	 */
	private Iterator<Move> getLegalMoves(int playerInt) {
		ArrayList<Move> legalMoves = new ArrayList<Move>();
		for(int x = 0; x < board.length; x++) {
			for(int y = board[0].length-1; y >= 0; y--) {
				Move move = new Move(x,y);
				if(board[x][y] == ConnectFourGame.EMPTY ){
					legalMoves.add(move);
					break;
				}
			}
		}
		return legalMoves.iterator();
	}
	
	
	
	/**
	 * Class to describe a move and it's value
	 * @author Wim, Mart, Bas en Jurrian
	 *
	 */
	private class Move {
		public int x;
		public int y;
		public double value = 0;
		
		
		public Move(int x, int y) {
			this.x = x;
			this.y = y;
		}
		
		public void setValue(int value){
			this.value = (double) value;
		}
		
		public String toString() {
			return x + "";
		}
	}
	public String fieldToString()
	{
	    String print = " |01234567\n";
	    print += "-+---\n";
		for(int y = 0; y < board[0].length;y++){
			print += y+"|";
	    	for(int x = 0; x < board.length; x++){
	    		if(board[x][y] == ConnectFourGame.PLAYER_ONE){
	    			print += "X";
	    		}else if(board[x][y] == ConnectFourGame.PLAYER_TWO){
	    			print += "O";
	    		}else{
	    			print += "-";
	    		}
	    	}
	    	print += "\n";
	    }
		return print;
	}
}
