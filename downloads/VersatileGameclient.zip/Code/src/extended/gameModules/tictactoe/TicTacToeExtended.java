package extended.gameModules.tictactoe;

import extended.gameInterface.*;
import game.tictactoe.TicTacToeGame;

/**
 * Class implementing the client-side additional functions of tictactoe 
 * @author Wim, Mart, Bas, Jurrian
 */
public class TicTacToeExtended extends TicTacToeGame implements HasControllerView, AbstractExtendedGameModule {
	
	private TicTacToeControllerView cview;
	private AbstractGameAI ai;
	
	/**
	 * Constructor
	 * @param playerOne name
	 * @param playerTwo name
	 */
	public TicTacToeExtended(String playerOne, String playerTwo) {
		super(playerOne, playerTwo);
		ai = new TicTacToeAI(board);
		cview = new TicTacToeControllerView(this);
		cview.update(board, false);
	}
	
	public void allowPlayerMove() {
		cview.update(board, true);
	}
	
	@Override
	public void doPlayerMove(String player, String move){
		super.doPlayerMove(player, move);
		cview.update(board, false);
	}

	@Override
	public AbstractMoveActor getControllerView() {
		return cview;
	}

	@Override
	public AbstractGameAI getAI() {
		return ai;
	}
	
	/**
	 * Get the char of the current player.
	 * @return String
	 */
	public String getCurrentPlayerChar() {
		if(nextPlayer.equals(playerOne)) {
			return String.valueOf(playerOneChar);
		}
		return String.valueOf(playerTwoChar);
	}
	
	/**
	 * Get char of a specific player.
	 * @param playerInt
	 * @return String
	 */
	public String getPlayerChar(int playerInt) {
		if(playerInt == PLAYER_ONE) {
			return String.valueOf(playerOneChar);
		} else {
			return String.valueOf(playerTwoChar);
		}
	}

	/**
	 * Get playername with the player int.
	 * @param player
	 * @return
	 */
	public String getPlayerName(int player) {
		if(player == PLAYER_ONE) {
			return playerOne;
		}
		return playerTwo;
	}

}