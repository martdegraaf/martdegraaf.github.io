package extended.gameModules.tictactoe;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

import nl.hanze.t23i.gamemodule.extern.AbstractGameModule;

import extended.gameInterface.AbstractMoveActor;
import game.tictactoe.TicTacToeGame;

/**
 * ControllerView for TicTacToe, a grid with 3 rows and 3 columns of buttons
 * @author Wim, Mart, Bas, Jurrian
 */
public class TicTacToeControllerView extends AbstractMoveActor implements ActionListener {
	
	private final TicTacToeExtended gameModule;
	private final JButton[][] buttonGrid = new JButton[3][3];
	public static final Color BACKGROUND_COLOR = Color.white;
	private static final Color BORDER_COLOR = new Color(130, 170, 200);
	
	private final JLabel turn;
	
	public TicTacToeControllerView(TicTacToeExtended gameModule) {
		this.gameModule = gameModule;
		JPanel board = new JPanel();
		board.setLayout(new GridLayout(3,3));
		
		for(int y = 0; y < 3; y++) {
			for(int x = 0; x < 3; x++) {
				buttonGrid[x][y] = new JButton();
				buttonGrid[x][y].setFocusable(false);
				buttonGrid[x][y].addActionListener(this);
				board.add(buttonGrid[x][y]);
			}
		}
		
		//JPanel with color and turn information
		JPanel turnView = new JPanel();
		turnView.setLayout(new BorderLayout());
		turnView.setPreferredSize(new Dimension(150, 90));
		
		JLabel turnLabel = new JLabel("Turn: ");
		
		JLabel playerOneTxt = new JLabel(gameModule.getPlayerName(TicTacToeGame.PLAYER_ONE));
		JLabel playerOneChar = new JLabel();
		playerOneChar.setText(gameModule.getPlayerChar(TicTacToeGame.PLAYER_ONE));
		playerOneChar.setFont(new Font("Verdana", Font.BOLD, 20));
		playerOneChar.setForeground(Color.RED.darker());
		
		
		JLabel playerTwoTxt = new JLabel(gameModule.getPlayerName(TicTacToeGame.PLAYER_TWO));	
		JLabel playerTwoChar = new JLabel();
		playerTwoChar.setText(gameModule.getPlayerChar(TicTacToeGame.PLAYER_TWO));
		playerTwoChar.setFont(new Font("Verdana", Font.BOLD, 20));
		playerTwoChar.setForeground(Color.BLUE.darker());
		
		turn = new JLabel();
		
		JPanel turnPanel = new JPanel(new GridLayout(2,1));
		turnPanel.add(turnLabel,BorderLayout.NORTH);
		turnPanel.add(turn, BorderLayout.CENTER);
		turnView.add(turnPanel, BorderLayout.LINE_START);
		
		JPanel colorPanel = new JPanel(new GridLayout(2, 2));
		colorPanel.add(playerOneTxt);
		colorPanel.add(playerTwoTxt);
		colorPanel.add(playerOneChar);
		colorPanel.add(playerTwoChar);
		turnView.add(colorPanel, BorderLayout.LINE_END);
		
		board.setPreferredSize(new Dimension(150, 150));
		
		add(board, BorderLayout.PAGE_START);
		add(turnView, BorderLayout.PAGE_END);
		
		setPreferredSize(new Dimension(150, 250));
	}
	
	/**
	 * A button was pressed, notify our moveListeners
	 */
	@Override
	public void actionPerformed(ActionEvent e) {
		Object source = e.getSource();
		for(int y = 0; y < 3; y++) {
			for(int x = 0; x < 3; x++) {
				if(source == buttonGrid[x][y]) {
					notifyListeners(x + "," + y);
					disableButton(buttonGrid[x][y]);
				}
			}
		}
	}
	
	private void disableButton(JButton button) {
		button.removeActionListener(this);
		button.setBorder(BorderFactory.createLineBorder(BORDER_COLOR));
	}
	
	/**
	 * Updates the view when it should
	 * @param board data
	 * @param isPlayerHuman?
	 */
	public void update(int[][] board, boolean playerIsHuman) {
		for(int y = 0; y < buttonGrid[0].length; y++) {
			for(int x = 0; x < buttonGrid.length; x++) {
				char c;
				if(board[x][y] == TicTacToeGame.PLAYER_ONE){
					c = TicTacToeGame.playerOneChar;
					disableButton(buttonGrid[x][y]);
					buttonGrid[x][y].setForeground(Color.RED.darker());
				}
				else if(board[x][y] == TicTacToeGame.PLAYER_TWO){
					c= TicTacToeGame.playerTwoChar;
					disableButton(buttonGrid[x][y]);
					buttonGrid[x][y].setForeground(Color.BLUE.darker());
				}
				else {
					if(playerIsHuman) buttonGrid[x][y].setEnabled(true);
					c = ' ';
				}
				buttonGrid[x][y].setOpaque(true);
				buttonGrid[x][y].setBackground(BACKGROUND_COLOR);
				//TODO: Color on the text
				buttonGrid[x][y].setText("" + c);
				buttonGrid[x][y].setFont(new Font("Verdana", Font.BOLD, 20));
			}
		}
		if(gameModule.getMatchStatus() == AbstractGameModule.MATCH_STARTED) {
			updateTurnView();
		}
	}
	
	/**
	 * Update the turnView
	 */
	public void updateTurnView() {		
		String playerChar = gameModule.getCurrentPlayerChar();
		if(playerChar.equals("X")){
			turn.setForeground(Color.RED.darker());
		}else{
			turn.setForeground(Color.BLUE.darker());
		}
		turn.setText(playerChar);
		turn.setFont(new Font("Verdana", Font.BOLD, 20));
	}
}
