package extended.gameModules.othello;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import nl.hanze.t23i.gamemodule.extern.AbstractGameModule;

import extended.gameInterface.AbstractMoveActor;
import game.othello.OthelloBoard;
import game.othello.OthelloGame;
import game.othello.OthelloStone;

/**
 * ControllerView for TicTacToe, a grid with 3 rows and 3 columns of buttons
 * @author Wim, Mart, Bas, Jurrian
 */
public class OthelloControllerView extends AbstractMoveActor implements ActionListener {
	
	private OthelloStone[][] buttonGrid = new OthelloStone[OthelloBoard.WIDTH][OthelloBoard.HEIGHT];
	private OthelloExtended gameModule;
	
	private JButton turn;
	private JLabel countOne;
	private JLabel countTwo;
	
	public OthelloControllerView(OthelloExtended gameModule) {
		this.gameModule = gameModule;
		JPanel board;board = new JPanel();
		board.setLayout(new GridLayout(8,8));
		
		for(int y = 0; y < buttonGrid[0].length; y++) {
			for(int x = 0; x < buttonGrid.length; x++) {
				OthelloStone b = new OthelloStone();
				b.addActionListener(this);
				
				JPanel tile = new JPanel();
				tile.setBackground(OthelloStone.BACKGROUND_COLOR);
				tile.setLayout(new GridLayout(1,1));
				tile.add(b);
				tile.setBorder(BorderFactory.createLineBorder(Color.BLACK));
				
				board.add(tile);
				buttonGrid[x][y] = b;
			}
		}
		
		String playerOneName = gameModule.getPlayerName(OthelloGame.PLAYER_ONE);
		JLabel playerOneTxt = new JLabel(playerOneName, SwingConstants.CENTER);
		playerOneTxt.setOpaque(true);
		playerOneTxt.setBackground(OthelloStone.BACKGROUND_COLOR);
		playerOneTxt.setForeground(Color.WHITE);
		OthelloStone playerOneCol = new OthelloStone();
		playerOneCol.setColor(gameModule.getPlayerColor(OthelloGame.PLAYER_ONE));
		playerOneCol.setEnabled(false);
		playerOneCol.setPreferredSize(new Dimension(49, 49));
		JPanel playerOneColContainer = new JPanel();
		playerOneColContainer.add(playerOneCol);
		playerOneColContainer.setBackground(OthelloStone.BACKGROUND_COLOR);
		
		String playerTwoName = gameModule.getPlayerName(OthelloGame.PLAYER_TWO);
		JLabel playerTwoTxt = new JLabel(playerTwoName, SwingConstants.CENTER);
		playerTwoTxt.setOpaque(true);
		playerTwoTxt.setBackground(OthelloStone.BACKGROUND_COLOR);
		playerTwoTxt.setForeground(Color.WHITE);
		OthelloStone playerTwoCol = new OthelloStone();
		playerTwoCol.setColor(gameModule.getPlayerColor(OthelloGame.PLAYER_TWO));
		playerTwoCol.setEnabled(false);
		playerTwoCol.setPreferredSize(new Dimension(49, 49));
		JPanel playerTwoColContainer = new JPanel();
		playerTwoColContainer.add(playerTwoCol);
		playerTwoColContainer.setBackground(OthelloStone.BACKGROUND_COLOR);
		
		turn = new OthelloStone();
		turn.setEnabled(false);
		turn.setPreferredSize(new Dimension(49, 49));
		
		JPanel turnPanel = new JPanel(new BorderLayout());
		JLabel turnLabel = new JLabel("Turn: ", SwingConstants.CENTER);
		turnLabel.setOpaque(true);
		turnLabel.setBackground(OthelloStone.BACKGROUND_COLOR);
		turnLabel.setForeground(Color.WHITE);
		turnPanel.add(turnLabel, BorderLayout.NORTH);
		turnPanel.add(turn, BorderLayout.CENTER);
		
		JPanel playerOneColorTile = new JPanel(new BorderLayout());
		playerOneColorTile.add(playerOneTxt, BorderLayout.NORTH);
		playerOneColorTile.add(playerOneColContainer, BorderLayout.CENTER);
		
		JPanel playerTwoColorTile = new JPanel(new BorderLayout());
		playerTwoColorTile.add(playerTwoTxt, BorderLayout.NORTH);
		playerTwoColorTile.add(playerTwoColContainer, BorderLayout.CENTER);
		
		JPanel colorPanel = new JPanel();
		colorPanel.setLayout(new GridLayout(1, 2));
		colorPanel.setOpaque(true);
		colorPanel.setBackground(OthelloStone.BACKGROUND_COLOR);
		colorPanel.add(playerOneColorTile);
		colorPanel.add(playerTwoColorTile);
		
		//JPanel with color and turn information
		JPanel turnView = new JPanel();
		turnView.setLayout(new BorderLayout());
		
		JPanel tileCountPanel = new JPanel();
		tileCountPanel.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
		tileCountPanel.setOpaque(true);
		tileCountPanel.setBackground(Color.BLACK);
		tileCountPanel.setLayout(new GridLayout(2,2));
		
		JLabel countOneTitle = new JLabel(playerOneName + " tiles: ");
		JLabel countTwoTitle = new JLabel(playerTwoName + " tiles: ");
		countOne = new JLabel();
		countTwo = new JLabel();
		countOneTitle.setForeground(Color.WHITE);
		countTwoTitle.setForeground(Color.WHITE);
		countOne.setForeground(Color.WHITE);
		countTwo.setForeground(Color.WHITE);

		tileCountPanel.add(countOneTitle);
		tileCountPanel.add(countOne);
		tileCountPanel.add(countTwoTitle);
		tileCountPanel.add(countTwo);
		
		JPanel filler = new JPanel();
		filler.setOpaque(true);
		filler.setBackground(OthelloStone.BACKGROUND_COLOR);
		
		turnView.add(turnPanel, BorderLayout.WEST);
		turnView.add(filler, BorderLayout.CENTER);
		turnView.add(colorPanel, BorderLayout.EAST);
		turnView.add(tileCountPanel, BorderLayout.NORTH);
		turnView.setOpaque(true);
		turnView.setBackground(OthelloStone.BACKGROUND_COLOR);
		turnView.setBorder(BorderFactory.createEmptyBorder(5, 5, 0, 5));
		
		board.setPreferredSize(new Dimension(400, 400));
		
		setLayout(new BorderLayout(5, 5));
		add(board, BorderLayout.NORTH);
		add(turnView, BorderLayout.PAGE_END);
	}
	
	/**
	 * A button was pressed, notify our moveListeners
	 */
	@Override
	public void actionPerformed(ActionEvent e) {
		Object source = e.getSource();
		for(int x = 0; x < buttonGrid.length; x++) {
			for(int y = 0; y < buttonGrid[x].length; y++) {
				if(source == buttonGrid[x][y]) {
					buttonGrid[x][y].setEnabled(false);
					notifyListeners(x + "," + y);
				}
			}
		}
	}
	
	/**
	 * Updates the view when it should
	 * @param board data
	 * @param isPlayerHuman?
	 */
	public void update(OthelloBoard board, boolean playerIsHuman) {
		int[][] grid = board.getArray();
		
		for(int x = 0; x < buttonGrid.length; x++) {
			for(int y = 0; y < buttonGrid[x].length; y++) {
				OthelloStone b = buttonGrid[x][y]; 
				b.setEnabled(false);
				Color c;
				if(grid[x][y] == OthelloGame.PLAYER_ONE) c = Color.WHITE;
				else if(grid[x][y] == OthelloGame.PLAYER_TWO) c= Color.BLACK;
				else {
					if(playerIsHuman) b.setEnabled(true);
					c = OthelloStone.BACKGROUND_COLOR;
				}
				b.setColor(c);
			}
		}		
		updateTurnView(board);
	}
	
	/**
	 * Update the turnView.
	 * @param board
	 */
	public void updateTurnView(OthelloBoard board) {
		int playerOneCount = board.countPlayerStones(OthelloGame.PLAYER_ONE);
		countOne.setText(Integer.toString(playerOneCount));
		
		int playerTwoCount = board.countPlayerStones(OthelloGame.PLAYER_TWO);
		countTwo.setText(Integer.toString(playerTwoCount));
		
		if(gameModule.getMatchStatus() == AbstractGameModule.MATCH_STARTED) {
			String player = gameModule.getPlayerToMove();
			Color color = gameModule.getCurrentPlayerColor();
			turn.setForeground(color);
			turn.setText(player);
		}
	}
	
	
}
