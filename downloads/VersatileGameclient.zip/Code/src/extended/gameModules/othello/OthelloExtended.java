package extended.gameModules.othello;


import java.awt.Color;

import extended.gameInterface.*;
import game.othello.OthelloGame;

/**
 * Class implementing the client-side additional functions of Othello 
 * @author Wim, Mart, Bas, Jurrian
 */
public class OthelloExtended extends OthelloGame implements HasControllerView, AbstractExtendedGameModule {
	
	private OthelloControllerView cview;
	private AbstractGameAI ai;
	
	/**
	 * Constructor
	 * @param playerOne name
	 * @param playerTwo name
	 */
	public OthelloExtended(String playerOne, String playerTwo) {
		super(playerOne, playerTwo);
		
		if(OthelloAI.USE_THREADING) {
			ai = new OthelloAIThreaded(board);
		}
		else {
			ai = new OthelloAI(board);
		}
		cview = new OthelloControllerView(this);
		cview.update(board, false);
	}
	
	/**
	 * Method to allow the client to move.
	 */
	public void allowPlayerMove() {
		cview.update(board, true);
	}
	
	@Override
	public void doPlayerMove(String player, String move){
		super.doPlayerMove(player, move);
		cview.update(board, false);
	}

	@Override
	public AbstractMoveActor getControllerView() {
		return cview;
	}

	@Override
	public AbstractGameAI getAI() {
		return ai;
	}
	
	/**
	 * Get the color of the current player.
	 * @return
	 */
	public Color getCurrentPlayerColor() {
		if(nextPlayer.equals(playerOne)) {
			return playerOneColor;
		}
		return playerTwoColor;
	}
	
	/**
	 * Get the color of a specific player.
	 * @param playerInt
	 * @return
	 */
	public Color getPlayerColor(int playerInt) {
		if(playerInt == PLAYER_ONE) {
			return playerOneColor;
		} else {
			return playerTwoColor;
		}
	}

	/**
	 * Get player name by player int.
	 * @param player
	 * @return String
	 */
	public String getPlayerName(int player) {
		if(player == PLAYER_ONE) {
			return playerOne;
		}
		return playerTwo;
	}
	
}