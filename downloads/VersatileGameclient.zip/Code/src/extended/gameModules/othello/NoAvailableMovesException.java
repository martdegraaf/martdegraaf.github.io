package extended.gameModules.othello;

/**
 * NoAvailableMovesException class.
 * @author Mart, Wim, Bas, Jurrian
 *
 */
public class NoAvailableMovesException extends Exception{

	public NoAvailableMovesException(String string) {
		super(string);
	}
	
	
}
