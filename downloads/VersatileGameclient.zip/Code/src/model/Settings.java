package model;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.PrintWriter;
import java.util.Scanner;

/**
 * Settings class
 * @author Wim, Mart, Bas, Jurrian
 *
 */
public class Settings {
	private static final String SAVE_FILE = "settings.conf";
	
	// Constants
	public static final int COMPUTER = 0;	// Used for player setting
	public static final int HUMAN = 1;		// Used for player setting
	public static final int LOCAL = 0;		// used for environment setting
	public static final int NETWORK = 1;	// used for environment setting
	public static final int CHALLENGE = 0;	// Used to challenge a player to a game, or subscribe to that game
	public static final int SUBSCRIBE = 1;	// Used to challenge a player to a game, or subscribe to that game
	
	public static final int EASY = 0;		//Used for difficulty
	public static final int MEDIUM = 1;		//Used for difficulty
	public static final int HARD = 2;		//Used for difficulty
	public static final int LOG_SIZE = 100;
	
	// Settings
	public static int DIFFICULTY = 2;				// Standard value for difficulty
	public static String NAME = "Alpha";			// Username that shows when you try connect to a server or start a local game
	public static String SERVER = "wimbarelds.nl";	// Server that shows when you try connect for a network game
	public static int TURN_TIME = 15; 				// Time a player gets to think before playing a move
	
	/**
	 * Loads settings from file
	 */
	public static void initialize() {
		Scanner settingsFile;
		try {
			settingsFile = new Scanner(new FileReader(SAVE_FILE));
		} catch (FileNotFoundException e) {
			System.err.println("Could not load settings from file.");
			return;
		}
		
		while(settingsFile.hasNextLine()) {
			String line = settingsFile.nextLine();
			if(line.contains("=")) {
				String[] parts = line.split("=");
				String setting = parts[0];
				String value = parts[1];
				
				if(setting.equals("DIFFICULTY")) {
					int diff = Integer.parseInt(value);
					if(diff >= EASY && diff <= HARD) DIFFICULTY = diff;
				}
				else if(setting.equals("NAME")) {
					if(value.length() > 0) NAME = value;
				}
				else if(setting.equals("SERVER")) {
					if(value.length() > 0 && value.contains(".")) SERVER = value;
				}
				else if(setting.equals("TURN_TIME")) {
					int time = Integer.parseInt(value);
					if(time > 0 && time <= 120) TURN_TIME = time;
				}
			}
		}
		settingsFile.close();
	}
	
	/**
	 * Saves settings to file
	 */
	public static void save() {
		try {
			PrintWriter out = new PrintWriter(SAVE_FILE);
			out.println("DIFFICULTY=" + DIFFICULTY);
			out.println("NAME=" + NAME);
			out.println("SERVER=" + SERVER);
			out.println("TURN_TIME=" + TURN_TIME);
			out.close();
		} catch (FileNotFoundException e) {
			System.err.println("Could not save settings to file.");
		}
	}
}
