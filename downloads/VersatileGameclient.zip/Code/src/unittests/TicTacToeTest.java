package unittests;

import static org.junit.Assert.*;
import game.tictactoe.TicTacToeGame;

import org.junit.Test;

public class TicTacToeTest {

	@Test
	public void test() {
		TicTacToeGame tg = new TicTacToeGame("1", "2");
		tg.start();
	}
	@Test
	public void testMove() {
		TicTacToeGame tg = new TicTacToeGame("1", "2");
		//Start a new Othello game
		tg.start();
		
		
		//Put a stone from player one there
		tg.doPlayerMove("1", "0,0");
		
		//invalid move
		tg.doPlayerMove("2", "0,0");
		
		assertTrue(tg.getMatchStatus() == TicTacToeGame.MATCH_FINISHED);
		
	}
	
	@Test
	public void testInitializeGame() {
		TicTacToeGame tg = new TicTacToeGame("1", "2");
		
		assertTrue(tg.getMatchStatus() == TicTacToeGame.MATCH_INITIALIZED);
		
		//Start a new Othello game
		tg.start();
		
		assertTrue(tg.getMatchStatus() == TicTacToeGame.MATCH_STARTED);
		
		tg.doPlayerMove("1", "0,0");
		tg.doPlayerMove("2", "1,0");
		tg.doPlayerMove("1", "0,1");
		tg.doPlayerMove("2", "2,0");
		tg.doPlayerMove("1", "0,2");
		
		assertTrue(tg.getMatchStatus() == TicTacToeGame.MATCH_FINISHED);
	}
	
	@Test
	public void testMoveAfterGame() {
		TicTacToeGame tg = new TicTacToeGame("1","2");
		tg.start();
		
		if(tg.getMatchStatus() == TicTacToeGame.MATCH_FINISHED){
			try{
				tg.doPlayerMove("1", "0,0");
				fail("No exception here?");
			}catch(IllegalStateException e){
				//Here's the exception we are looking for
			}
		}
	}
	
	@Test
	public void testPlayerTurn(){
		TicTacToeGame tg = new TicTacToeGame("1","2");
		tg.start();
		
		//Test if it's possible for a player whose turn isn't up to make a move
		if(tg.getMatchStatus() == TicTacToeGame.MATCH_FINISHED){
			try{
				tg.doPlayerMove("2", "0,0");
				fail("No exception here?");
			}catch (IllegalStateException e){
				//Here's the exception we are looking for
			}
		}
	}

}
