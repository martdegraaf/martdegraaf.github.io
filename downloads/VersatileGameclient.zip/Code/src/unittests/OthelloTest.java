package unittests;

import static org.junit.Assert.*;
import game.othello.OthelloGame;

import org.junit.Test;


public class OthelloTest {

	@Test
	public void testMove() {
		OthelloGame og  = new OthelloGame("1", "2");
		//Start a new Othello game
		og.start();
		
		
		//Put a stone from player one there
		og.doPlayerMove("1", "2,4");
		assertTrue(og.getMatchStatus() == OthelloGame.MATCH_STARTED);
	}
	
	
	@Test
	public void testMoveAfterMatch() {
		OthelloGame og  = new OthelloGame("1", "2");
		og.start();
		if(og.getMatchStatus() == OthelloGame.MATCH_FINISHED){
			try{
				og.doPlayerMove("1", "2,4");
				fail("No exception here?");
			}catch(IllegalStateException e){
				//Here is the expected exception 
			}
		}
	}
	
	@Test
	public void testIllegalMove() {
		OthelloGame og  = new OthelloGame("1", "2");
		//Start a new Othello game
		og.start();
		
		
		//Put a stone from player one on 0,0 This is an invalid move
		og.doPlayerMove("1", "0,0");
		//Check if match is finished
		assertTrue(og.getMatchStatus() == OthelloGame.MATCH_FINISHED);
	}
	@Test
	public void testYourTurn() {
		OthelloGame og  = new OthelloGame("1", "2");
		//Start a new Othello game
		og.start();
		
		
		//Have player 2 make a move while it is not his turn
		og.doPlayerMove("2", "4,3");
		//check if game finished
		if(og.getMatchStatus() != OthelloGame.MATCH_FINISHED){
			fail("Match not finished and player did not do a valid move");
		}
	}
	
	@Test
	public void testOverwriteMove() {
		OthelloGame og  = new OthelloGame("1", "2");
		//Start a new Othello game
		og.start();
		//Do a move and check if the field is still available
		og.doPlayerMove("1", "2,4");
		assertFalse(og.getBoard().isValidMove(2,2,4));
	}
	
	@Test
	public void testInitializeGame() {
		OthelloGame og  = new OthelloGame("1", "2");
		
		assertTrue(og.getMatchStatus() == OthelloGame.MATCH_INITIALIZED);
		
		//Start a new Othello game
		og.start();
		
		assertTrue(og.getMatchStatus() == OthelloGame.MATCH_STARTED);
		
		//assertTrue(og.countStones("1") == 2);
		//assertTrue(og.countStones("2") == 2);
		
	}
	
	@Test
	public void testCapture() {
		OthelloGame og  = new OthelloGame("1", "2");
		og.start();
		og.doPlayerMove("1", "2,4");
		//Tests whether capturing a stone actually makes it switch sides
		assertTrue(og.getBoard().getArray()[3][4] == OthelloGame.PLAYER_ONE);
	}
	

}
