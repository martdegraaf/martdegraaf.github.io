package unittests;

import static org.junit.Assert.*;
import game.connectfour.ConnectFourGame;

import org.junit.Test;

public class ConnectFourTest {

	@Test
	public void testMove() {
		ConnectFourGame cfg = new ConnectFourGame("1", "2");
		cfg.start();
		//Do a legal move
		cfg.doPlayerMove("1", "4");
		assertTrue(cfg.getMatchStatus() == ConnectFourGame.MATCH_STARTED);
		
		//Do an illegal move
		cfg.doPlayerMove("1", "4");
		assertTrue(cfg.getMatchStatus() == ConnectFourGame.MATCH_FINISHED);
		
		//Try to do a move after the match has finished
		try{
			cfg.doPlayerMove("1", "4");
			fail("No exception?");
		}catch(IllegalStateException e){
			//Here's our exception
		}
		
	}
	
	@Test
	public void testVerticalWinDetection() {
		ConnectFourGame cfg = new ConnectFourGame("1", "2");
		cfg.start();
		
		assertTrue(cfg.getMatchStatus() == ConnectFourGame.MATCH_STARTED);
		
		cfg.doPlayerMove("1", "0");
		cfg.doPlayerMove("2", "1");
		cfg.doPlayerMove("1", "0");
		cfg.doPlayerMove("2", "1");
		cfg.doPlayerMove("1", "0");
		cfg.doPlayerMove("2", "1");
		cfg.doPlayerMove("1", "0");
		
		assertTrue(cfg.getMatchStatus() == ConnectFourGame.MATCH_FINISHED);
	}
	
	@Test
	public void testHorizontalWinDetection() {
		ConnectFourGame cfg = new ConnectFourGame("1", "2");
		cfg.start();
		
		assertTrue(cfg.getMatchStatus() == ConnectFourGame.MATCH_STARTED);
		
		cfg.doPlayerMove("1", "0");
		cfg.doPlayerMove("2", "0");
		cfg.doPlayerMove("1", "1");
		cfg.doPlayerMove("2", "1");
		cfg.doPlayerMove("1", "2");
		cfg.doPlayerMove("2", "2");
		cfg.doPlayerMove("1", "3");
		
		assertTrue(cfg.getMatchStatus() == ConnectFourGame.MATCH_FINISHED);
	}
	
	@Test
	public void testDiagonalWinDetection() {
		ConnectFourGame cfg = new ConnectFourGame("1", "2");
		cfg.start();
		
		assertTrue(cfg.getMatchStatus() == ConnectFourGame.MATCH_STARTED);
		
		cfg.doPlayerMove("1", "0");
		cfg.doPlayerMove("2", "1");
		cfg.doPlayerMove("1", "1");
		cfg.doPlayerMove("2", "2");
		cfg.doPlayerMove("1", "2");
		cfg.doPlayerMove("2", "3");
		cfg.doPlayerMove("1", "2");
		cfg.doPlayerMove("2", "3");
		cfg.doPlayerMove("1", "3");
		cfg.doPlayerMove("2", "5");
		cfg.doPlayerMove("1", "3");
		
		assertTrue(cfg.getMatchStatus() == ConnectFourGame.MATCH_FINISHED);
	}

}
