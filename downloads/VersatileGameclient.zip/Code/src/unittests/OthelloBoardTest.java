package unittests;

import static org.junit.Assert.*;

import java.lang.reflect.Method;

import extended.gameModules.othello.OthelloAI;
import game.othello.OthelloBoard;
import game.othello.OthelloMove;
import game.othello.OthelloGame;

import org.junit.Test;

public class OthelloBoardTest {
	
	public static final int DEPTH = 4;
	
	@Test
	public void test() {
		// Tests if the AI picks the corner if the alternative is a less important move
		OthelloBoard board = new OthelloBoard();
		board.initialize();

		int[][] b = board.getArray();
		b[0][1] = OthelloGame.PLAYER_ONE;
		b[0][2] = OthelloGame.PLAYER_TWO;
		b[1][0] = OthelloGame.PLAYER_TWO;
		b[2][0] = OthelloGame.PLAYER_ONE;
		
		b[2][3] = OthelloGame.PLAYER_TWO;
		b[3][3] = OthelloGame.PLAYER_TWO;
		
		OthelloBoard board2 = new OthelloBoard();
		board2.initialize();
		
		int[][] b2 = board2.getArray();
		b2[7][6] = OthelloGame.PLAYER_ONE;
		b2[7][5] = OthelloGame.PLAYER_TWO;
		b2[6][7] = OthelloGame.PLAYER_TWO;
		b2[5][7] = OthelloGame.PLAYER_ONE;
		
		b2[2][3] = OthelloGame.PLAYER_TWO;
		b2[3][3] = OthelloGame.PLAYER_TWO;
		
		System.out.println(board);
		System.out.println(board2);
		
		//String bestMove = getBestMove(board.clone(), OthelloGame.PLAYER_TWO, 1).toString();
		//assertEquals("0,0", bestMove);
		OthelloMove bestMove = getBestMove(board.clone(), OthelloGame.PLAYER_ONE, DEPTH);
		assertEquals("0,0", bestMove.toString());
		OthelloMove bestMove2 = getBestMove(board2.clone(), OthelloGame.PLAYER_ONE, DEPTH);
		assertEquals("7,7", bestMove2.toString());
	}
	
	@Test
	public void testMoveIsBetter() {
		OthelloMove othelloMoveA = new OthelloMove(1,1);
		OthelloMove othelloMoveB = new OthelloMove(1,1);
		OthelloMove othelloMoveC = new OthelloMove(1,1);
		othelloMoveA.value = 0.1;
		othelloMoveB.value = 0.40;
		othelloMoveC.value = 2.0;
		assertTrue(othelloMoveA.isBetterThan(othelloMoveB, OthelloGame.PLAYER_ONE));
		assertTrue(othelloMoveB.isBetterThan(othelloMoveC, OthelloGame.PLAYER_ONE));
		assertTrue(othelloMoveB.isBetterThan(othelloMoveA, OthelloGame.PLAYER_TWO));
		assertFalse(othelloMoveA.isBetterThan(othelloMoveB, OthelloGame.PLAYER_TWO));
		assertFalse(othelloMoveB.isBetterThan(othelloMoveA, OthelloGame.PLAYER_ONE));
	}
	
	@Test (timeout=5000)
	public void testSomeoneCantMove() {
		// Tests if the AI breaks when one player (or both player's) can't move somewhere along the line
		OthelloBoard board = new OthelloBoard();
		int[][] b = board.getArray();
		b[0][2] = OthelloGame.PLAYER_ONE;
		b[0][1] = OthelloGame.PLAYER_TWO;
		b[0][3] = OthelloGame.PLAYER_TWO;
		
		b[3][4] = OthelloGame.PLAYER_ONE;
		b[4][3] = OthelloGame.PLAYER_ONE;
		
		String bestMove = getBestMove(board, OthelloGame.PLAYER_ONE, 6).toString();
		if(!bestMove.equals("0,0") && !bestMove.equals("0,4")) {
			fail("Should be one of these");
		}
	}
	
	/**
	 * Using getDeclaredMethod we can access private functions and test those
	 * @param board
	 * @param player
	 * @param AI recursion depth
	 * @return Best Move
	 */
	public static OthelloMove getBestMove(OthelloBoard board, int player, int depth) {
		//(OthelloBoard board, int player, int depth, OthelloMove alpha, OthelloMove beta) {
		OthelloAI ai = new OthelloAI(board);
		try {
			Method m = ai.getClass().getDeclaredMethod("bestMove", OthelloBoard.class, Integer.TYPE, Integer.TYPE, OthelloMove.class, OthelloMove.class);
			m.setAccessible(true);
			
			return (OthelloMove) m.invoke(ai, board, player, depth, null, null);
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println(e.getMessage());
			return null;
		}
	}
}
