package gameclient;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Modifier;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;

import extended.gameInterface.AbstractExtendedGameModule;

/**
 * ExtGameModuleLoader class. This class loads the .jar files found in the map gamemodules.
 * The ExtGameModuleLoader only handles AbstractExtendedGameModules.
 * @author Mart, Wim, Bas, Jurrian
 *
 */
public class ExtGameModuleLoader {

	private HashMap<String, Class<? extends AbstractExtendedGameModule>> gameModuleMap;
	private ArrayList<String> gameTypeList;
	
	public ExtGameModuleLoader(File modulePath) {
		gameModuleMap = new HashMap<String, Class<? extends AbstractExtendedGameModule>>();
		loadJarFiles(modulePath);
		
		gameTypeList = new ArrayList<String>(gameModuleMap.keySet());
	}
	
	public ArrayList<String> getGameTypeList() {
		return gameTypeList;
	}
	
	public AbstractExtendedGameModule loadGameModule(String gameTypeName, String playerOne, String playerTwo) {
		AbstractExtendedGameModule gameModule = null;
		
		Class<? extends AbstractExtendedGameModule> gameModuleClass = gameModuleMap.get(gameTypeName);
		
		if(gameModuleClass == null) {
			return null;
		}
		
		try {
			Constructor<? extends AbstractExtendedGameModule> constructor = gameModuleClass.getConstructor(String.class, String.class);
			gameModule = constructor.newInstance(playerOne, playerTwo);
		} catch (InvocationTargetException e) {
			Throwable e2 = e.getTargetException();
			System.out.println(e2.getMessage());
			e2.printStackTrace();
			System.out.println("Error loading game module '" + gameTypeName + "': " + e);
		} catch (Exception e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
			System.out.println("Error loading game module '" + gameTypeName + "': " + e);
		}
		
		return gameModule;
	}
	
	private void loadJarFiles(File modulePath) {
		for(File jarFile: getJarFiles(modulePath)) {
			try {
				ArrayList<Class<? extends AbstractExtendedGameModule>> moduleClassList = loadGameModuleClasses(jarFile);
				loadGameModules(moduleClassList);
			} catch (IOException e) {
				System.out.println("Error loading Jar file '" + jarFile.getAbsolutePath() + "': " + e);
				//Log.ERROR.printf("Error loading Jar file '%s': %s", jarFile.getAbsolutePath(), e);
			}
		}
	}
	
	private void loadGameModules(ArrayList<Class<? extends AbstractExtendedGameModule>> moduleClassList) {
		for(Class<? extends AbstractExtendedGameModule> gameModuleClass: moduleClassList) {
			try {
				String gameType = (String) gameModuleClass.getField("GAME_TYPE").get(null);
				
				if(gameType == null || (gameType.trim().equals(""))) {
					continue;
				}
				
				gameModuleMap.put(gameType, gameModuleClass);
			} catch (Exception e) {
				System.err.println(e.getMessage());
				e.printStackTrace();
			}
		}
	}
	
	/**
	 * Loads game module classes from a Jar file.
	 * <p>
	 * This method will iterate the Jar file, looking for classes.<br />
	 * When it finds a class it will check if it is a (subclass of) <code>AbstractGameModule</code>, it is not abstract and is public.<br />
	 * If those criteria are met, then the class is added to the list of game module classes to be returned.
	 * @param file The Jar file containing the classes
	 * @return List of game module classes found in this Jar file
	 * @throws IOException If the Jar file is not found or the Jar file cannot be read
	 */
	private ArrayList<Class<? extends AbstractExtendedGameModule>> loadGameModuleClasses(File file) throws IOException {
		// Create classloader for loader classes from within Jar file
		URLClassLoader jarClassLoader = new URLClassLoader(new URL[]{file.toURI().toURL()}, ClassLoader.getSystemClassLoader());
		JarFile jarFile = new JarFile(file);
		
		// Store found game module classes
		ArrayList<Class<? extends AbstractExtendedGameModule>> classList = new ArrayList<Class<? extends AbstractExtendedGameModule>>();
		
		// Find classes, iterate through Jar file looking for classes who's superclass is castable to AbstractGameModule and is not abstract.
		for(Enumeration<JarEntry> entries = jarFile.entries(); entries.hasMoreElements(); ) {
			JarEntry jarEntry = entries.nextElement();
			
			// If entry is not a class: skip
			if(!jarEntry.getName().endsWith(".class")) {
				continue;
			}
			
			// Get class name: replace '/' with '.' and remove ".class" suffix
			String className = jarEntry.getName().replace('/', '.').replace(".class", "");
			
			try {
				// Load the class from the Jar file
				Class<?> clazz = Class.forName(className, true, jarClassLoader);
				
				try {
					// Try to cast the class to an AbstractGameModule
					Class<? extends AbstractExtendedGameModule> gameModuleClass = clazz.asSubclass(AbstractExtendedGameModule.class);
					
					// If class is abstract: skip
					if((gameModuleClass.getModifiers() & Modifier.ABSTRACT) == Modifier.ABSTRACT) {
						continue;
					}
					
					// If class not is public: skip
					if((gameModuleClass.getModifiers() & Modifier.PUBLIC) != Modifier.PUBLIC) {
						continue;
					}
					
					// Add class to game module class list
					classList.add(gameModuleClass);
				} catch (ClassCastException e) {
					;
				}
			} catch (ClassNotFoundException e) {
				;
			}
		}
		
		jarFile.close();
		
		return classList;
	}
	
	private ArrayList<File> getJarFiles(File modulePath) {
		ArrayList<File> jarList = new ArrayList<File>();
		
		for(File file: modulePath.listFiles()) {
			String filename = file.getAbsolutePath();
			if(filename.substring(filename.length() - 4).equalsIgnoreCase(".jar")) {
				jarList.add(file);
			}
		}
		
		return jarList;
	}

}