package gameclient;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

import model.Settings;

/**
 * Class that pops up when a user chooses to play a network game.
 * The connectionWindow holds an username textbox and a IP-adress textbox.
 * @author Mart, Wim, Bas, Jurrian
 *
 */
public class ConnectionWindow extends JDialog implements ActionListener {
	
	private GameClient client;
	private JTextField username;
	private JTextField server;
	
	public ConnectionWindow(GameClient client) {
		this.client = client;
		add(createGUI());
		
		setTitle("Connect to server");
		setModal(true);
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		pack();
		setResizable(false);
		setLocationRelativeTo(null); // center window
		setAlwaysOnTop(true);
		setVisible(true);
	}
	
	/**
	 * Create the JPanel
	 * @return JPanel
	 */
	private JPanel createGUI() {
		JPanel container = new JPanel();
		container.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
		container.setLayout(new BorderLayout(5, 5));
		
		JPanel labels = new JPanel();
		labels.setLayout(new GridLayout(1, 2, 5, 5));
		labels.add(new JLabel("Username:"));
		labels.add(new JLabel("Server:"));
		
		JPanel textfields = new JPanel();
		textfields.setLayout(new GridLayout(1, 2, 5, 5));
		username = new JTextField(Settings.NAME);
		server = new JTextField(Settings.SERVER);
		server.setHorizontalAlignment(SwingConstants.CENTER);
		textfields.add(username);
		textfields.add(server);
		textfields.setPreferredSize(new Dimension(300, 10));
		
		JButton submit = new JButton("Connect");
		submit.addActionListener(this);
		submit.setPreferredSize(new Dimension(200, 30));
		
		container.add(labels, BorderLayout.NORTH);
		container.add(textfields, BorderLayout.CENTER);
		container.add(submit, BorderLayout.SOUTH);
		
		return container;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		
		if(username.getText().equals("")) {
			JOptionPane.showMessageDialog(this, "You did not enter a username.");
			return;
		}
		
		if(server.getText().equals("")) {
			JOptionPane.showMessageDialog(this, "You did not enter a server.");
			return;
		}
		
		
		String serverName = server.getText();
		String playerName = username.getText();
		
		ConnectionHandler connectionHandler = client.getConnectionHandler();
		boolean success = connectionHandler.connect(serverName, playerName);
		if(!success) {
			JOptionPane.showMessageDialog(this, "Could not connect to server.");
			return;
		}
		
		// Connection succesful, so save these settings
		Settings.SERVER = serverName;
		Settings.NAME = playerName;
		Settings.save();
		
		// Update gamelist on client and clone connection window
		connectionHandler.getGameList();
		client.connectionSuccessful();
		dispose();
	}

}
