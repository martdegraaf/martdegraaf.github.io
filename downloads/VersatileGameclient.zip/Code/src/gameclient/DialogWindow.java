package gameclient;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JToggleButton;

/**
 * DialogWindow class that can be constructed with a certain message to display.
 * @author Mart, Wim, Bas, Jurrian
 *
 */
public class DialogWindow extends JFrame {
	
	JPanel content = new JPanel();
	
	public DialogWindow(JFrame parent, String title, String message, JComponent[] buttons) {
		createBaseWindow(parent, title, message);
		content.add(addButtons(buttons), BorderLayout.SOUTH);
		pack();
		setMinimumSize(new Dimension(300, 50));
	}
	
	public DialogWindow(final JFrame parent, String title, String message, boolean closeParent) {
		JButton ok = new JButton("OK");
		if(closeParent) {
			ok.addActionListener(new ActionListener() {
				@Override
			    public void actionPerformed(ActionEvent evt) {
			    	parent.dispose();
			    }
			});
		}
		createBaseWindow(parent, title, message);
		content.add(addButtons(new JButton[]{ ok }), BorderLayout.SOUTH);
		pack();
		setMinimumSize(new Dimension(300, 50));
	}
	
	private void createBaseWindow(JFrame parent, String title, String message) {
		content.setLayout(new BorderLayout(5, 5));
		content.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
		
		content.add(new JLabel("<html>" + message.replaceAll("\n", "<br>") + "</html>"), BorderLayout.NORTH);
		
		add(content);
		pack();
		setTitle(title);
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		setLocationRelativeTo(parent); // center window
		setResizable(false);
		setAlwaysOnTop(true);
		setVisible(true);		
	}
	
	private JPanel addButtons(JComponent[] buttons) {
		JPanel buttonPanel = new JPanel();
		buttonPanel.setLayout(new GridLayout(1, 5, 5, 5));
		buttonPanel.add(new JLabel());
		for(JComponent button : buttons) {
			if(button instanceof JButton)
			((JButton) button).addActionListener(new ActionListener() {
				@Override
			    public void actionPerformed(ActionEvent evt) {
			    	dispose();
			    }
			});
			if(button instanceof JToggleButton)
			((JToggleButton) button).addActionListener(new ActionListener() {
				@Override
			    public void actionPerformed(ActionEvent evt) {
			    	dispose();
			    }
			});
			buttonPanel.add(button);
			buttonPanel.add(new JLabel());
		}
		return buttonPanel;
	}
}
