package gameclient.window;

import java.util.HashMap;

import javax.swing.JOptionPane;

import model.Settings;
import nl.hanze.t23i.gamemodule.extern.AbstractGameModule;
import gameclient.ExtGameModuleLoader;
/**
 * Class that holds all games that run local.
 * @author Mart, Bas, Wim, Jurrian
 *
 */
public class GameWindowLocal extends GameWindow {
	
	private final String playerTwoName;
	private final int playerTwoType;
	
	public GameWindowLocal(String gamename, String playername, int playerType, String playerTwoName, int playerTwoType, ExtGameModuleLoader loader) {
		super(gamename, playername, playerType, loader);
		
		this.playerTwoName = playerTwoName;
		this.playerTwoType = playerTwoType;
	}

	@Override
	public void canMove(boolean canMove) {
		
		int playerType = this.playerType;
		if(canMove) {
			
			String playerToMove = gameModule.getPlayerToMove();
			if(!playerToMove.equals(playerName)) {
				playerType = playerTwoType;
			}
			
			if(playerType == Settings.COMPUTER) {
				// If AI, and AI's turn, make the move
				gameModule.getAI().getBestMove(gameModule.getPlayerInt(playerToMove));
			}
		}
		if(playerType != Settings.COMPUTER) {
			// If human player, make stuff clickable
			gameModule.allowPlayerMove();
			submitBtn.setEnabled(canMove);
		}
		
	}
	
	/**
	 * Start the game
	 * @param data
	 */
	public void start(HashMap<String, String> data) {
		super.start(data);
		canMove(true);
	}
	
	private String otherPlayer(String playerName) {
		if(this.playerName.equals(playerName)) return playerTwoName;
		return this.playerName;
	}
	
	
	@Override
	public void movePerformed(String move) {
		if(!isShowing()) return;
		
		int matchStatus;
		// Make a move
		String player = gameModule.getPlayerToMove();
		gameModule.doPlayerMove(player, move);
		moveTxt.setText("");
		canMove(false);
		
		// After a move is made
		matchStatus = gameModule.getMatchStatus();
		if(matchStatus == AbstractGameModule.MATCH_FINISHED) {
			matchEnded(player);
		}
		else if(matchStatus == AbstractGameModule.MATCH_STARTED) {
			canMove(true);
		}
	}
	
	/**
	 * Method to display the game result when the game is finished.
	 * @param player
	 */
	private void matchEnded(String player) {
		int playerResult = gameModule.getPlayerResult(player);
		String resultMessage;
		if(playerResult == AbstractGameModule.PLAYER_DRAW) {
			resultMessage = "The game ended in a draw.";
		}
		else {
			String winningPlayer;
			if(playerResult == AbstractGameModule.PLAYER_WIN) {
				winningPlayer = player;
			}
			else {
				
				winningPlayer = otherPlayer(player);
			}
			resultMessage = winningPlayer + " has won the game!";
			
		}
		JOptionPane.showMessageDialog(this, resultMessage + "\n\n" + gameModule.getMatchResultComment());
		dispose();
	}
}
