package gameclient.window;

import java.util.Timer;
import java.util.TimerTask;

import javax.swing.JProgressBar;

import model.Settings;

/**
 * Class to update the timer of the turn.
 * @author Mart, Jurrian, Bas, Wim
 *
 */
public class TimerUpdate extends TimerTask {
	Timer timer;
	JProgressBar bar;
	private final int delay = 0;
	private final int period = 1000;
	private int time = Settings.TURN_TIME;
	
	public TimerUpdate(JProgressBar bar) {
		this.bar = bar;
		timer = new Timer();
		timer.scheduleAtFixedRate(this, delay, period);
	}
	/**
	 * Stop the timer
	 */
	public void stop() {
		timer.cancel();
	}
	
	@Override
	public void run() {
    	bar.setValue(time);
    	bar.setString(bar.getValue() + " seconds");
    	time --;
	}

}
