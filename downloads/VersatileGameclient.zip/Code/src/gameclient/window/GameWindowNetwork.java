package gameclient.window;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JProgressBar;

import nl.hanze.t23i.gamemodule.extern.AbstractGameModule;

import model.Settings;
import extended.gameInterface.AbstractGameAI;

import gameclient.ConnectionHandler;
import gameclient.DialogWindow;
import gameclient.ExtGameModuleLoader;
/**
 * Class that holds all the games that go over the network.
 * @author Mart, Wim, Bas, Jurrian
 *
 */
public class GameWindowNetwork extends GameWindow {

	private ConnectionHandler connectionHandler;
	private TimerUpdate timerUpdate;
	private JProgressBar progressBar;
	
	public GameWindowNetwork(String gamename, String playername, int playerType, ExtGameModuleLoader loader, final ConnectionHandler connectionHandler) {
		super(gamename, playername, playerType, loader);
		this.connectionHandler = connectionHandler;
		
		setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		addWindowListener(new WindowAdapter() {

            @Override
            public void windowClosing(WindowEvent e) {
            	if(gameModule.getMatchStatus() != AbstractGameModule.MATCH_FINISHED){
            		connectionHandler.forfeit();
            	}
            }
        });
		
		progressBar = new JProgressBar(0, Settings.TURN_TIME);
		progressBar.setValue(Settings.TURN_TIME);
		progressBar.setStringPainted(true);
		progressBar.setString(Settings.TURN_TIME + " seconds");
		
		JPanel timeView = new JPanel(new GridLayout(1,1));
		timeView.add(progressBar);
		add(timeView, BorderLayout.NORTH);
		timerUpdate = new TimerUpdate(progressBar);
	}
	
	@Override
	public void canMove(boolean canMove) {
		if(playerType == Settings.COMPUTER) {
			// If AI, and AI's turn, make the move
			if(canMove) {
				String playerToMove = gameModule.getPlayerToMove();
				int playerInt = gameModule.getPlayerInt(playerToMove);
				AbstractGameAI ai = gameModule.getAI();
				ai.getBestMove(playerInt);
			}
		}
		else {
			// If human player, make stuff clickable
			gameModule.allowPlayerMove();
			submitBtn.setEnabled(canMove);
		}
	}
	
	/**
	 * Method to receive moves from outside.
	 */
	public void movePerformed(String move) {
		connectionHandler.makeMove(move);
		updateTimer();
		moveTxt.setText("");
		canMove(false);
	}
	
	/**
	 * Function to show the user that the game has ended.
	 * @param result
	 * @param msg
	 */
	public void gameEnded(String result, String msg) {
		if(result.equals("WIN")) {
			new DialogWindow(this, "The game has ended", "You have won! \n\n" + msg, true);
		}
		else if(result.equals("LOSS")){
			new DialogWindow(this, "The game has ended", "You have lost. \n\n" + msg, true);
		}
		else {
			new DialogWindow(this, "The game has ended", "The game ended in a draw. \n\n" + msg, true);
		}
	}
	
	/**
	 * Function to update the timer during the game
	 */
	public void updateTimer() {
		progressBar.setValue(Settings.TURN_TIME);
		if(timerUpdate != null) {
			timerUpdate.stop();
		}
		timerUpdate = new TimerUpdate(progressBar);
	}

}
