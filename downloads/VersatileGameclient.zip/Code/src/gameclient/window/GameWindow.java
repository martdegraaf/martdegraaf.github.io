package gameclient.window;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashMap;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;

import extended.gameInterface.AbstractExtendedGameModule;
import extended.gameInterface.HasControllerView;
import extended.gameInterface.MoveListener;
import gameclient.ExtGameModuleLoader;

/**
 * JFrame with the game inside it
 * @author Wim, Mart, Bas, Jurrian
 */
public abstract class GameWindow extends JFrame implements ActionListener, MoveListener {
	
	protected AbstractExtendedGameModule gameModule;		
	private ExtGameModuleLoader loader;
	
	protected final String playerName;
	protected final int playerType;
	
	protected JTextField moveTxt;
	protected JButton submitBtn;
	private JPanel container;
	private JPanel actionPanel;
	
	public GameWindow(String gamename, String playerName, int playerType, ExtGameModuleLoader loader) {
		this.loader = loader;
		this.playerName = playerName;
		this.playerType = playerType;
		this.setLayout(new BorderLayout());
		
		// Build frame
		container = new JPanel();
		container.setLayout(new BorderLayout(5, 5));
		container.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
		container.setOpaque(true);
		
		actionPanel = new JPanel();
		actionPanel.setLayout(new GridLayout(0, 2, 5, 5));
		
		moveTxt = new JTextField();
		submitBtn = new JButton("Submit");
		submitBtn.addActionListener(this);
		submitBtn.setEnabled(false);
		actionPanel.add(moveTxt);
		actionPanel.add(submitBtn);
		// We add this panel when the game starts, and the game turns out to not have a ControllerView
		
		add(container, BorderLayout.PAGE_END);
		
		
		// Show frame
		setTitle(gamename + ": Game window");
		pack();
		Dimension dimension = Toolkit.getDefaultToolkit().getScreenSize();
	    int x = (int) (dimension.getWidth() / 2 - 250);
	    int y = (int) (dimension.getHeight() / 2 - 250);
	    setLocation(x, y);
		setResizable(false);
		setVisible(true);
	}
	/**
	 * 
	 * Function to check if can move and then notifies the AI or the player.
	 * @param canMove
	 */
	public abstract void canMove(boolean canMove);

	@Override
	public void actionPerformed(ActionEvent e) {
		Object src = e.getSource();
		if(src == submitBtn) {
			movePerformed(moveTxt.getText());
		}
	}
	/**
	 * Start the game
	 * @param data
	 */
	public void start(HashMap<String, String> data) {
		String p1 = data.get("PLAYERTOMOVE");
		String p2 = data.get("OPPONENT");
		
		if(p1.equals(p2)) {
			p2 = playerName;
		}
		
		String gametype = data.get("GAMETYPE"); 
		gameModule = loader.loadGameModule(gametype, p1, p2);
		if(gameModule == null) {
			System.out.println("Wait here...");
		}
		gameModule.getAI().addMoveListener(this);
		
		if(gameModule instanceof HasControllerView) {
			HasControllerView controllerView = (HasControllerView) gameModule;
			controllerView.getControllerView().addMoveListener(this);				// The controller view needs to know where to send actions
			container.add(controllerView.getControllerView(), BorderLayout.CENTER);	// Add the controllerView as view
		}
		else {
			container.add(gameModule.getView(), BorderLayout.CENTER);
			container.add(actionPanel, BorderLayout.SOUTH);
		}
		gameModule.start(); 
		pack();	
	}
	/**
	 * Method to process a move 
	 * @param data
	 */
	public void processMove(HashMap<String, String> data) {
		gameModule.doPlayerMove(data.get("PLAYER"), data.get("MOVE"));
	}
	
}
