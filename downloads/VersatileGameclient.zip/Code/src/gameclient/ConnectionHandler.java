package gameclient;

import gameclient.window.GameWindowNetwork;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.ArrayList;
import java.util.HashMap;

import javax.swing.JFrame;

import model.Settings;

/**
 * Class to handle all connections between the client and server.
 * @author Mart, Wim, Bas, Jurrian
 *
 */
public class ConnectionHandler implements Runnable {
	
	private ArrayList<String> messageLog;
	private ConnectionConsole console;
	
	private Socket sock;
	private Thread thread;
	private Thread playerListThread;
	private PlayerCheck playerCheck;
	private boolean status = false;
	
	// Used to 
	private GameClient client;
	private GameWindowNetwork gameWindow;
	
	private HashMap<Integer, JFrame> challenges; // Stores all challenges by challengenumber 
	
	private String playerName;
	
	public ConnectionHandler(GameClient client) {
		this.messageLog = new ArrayList<String>();
		this.challenges = new HashMap<Integer, JFrame>();
		this.client = client;
	}
	
	/**
	 * Send command to the server.
	 * @param command
	 */
	public void sendCommand(String command) {
		if(!status) {
			if(!sock.isClosed()) {
				try { sock.close(); } catch (IOException e) {}
			}
			client.disconnect("Connection to server was lost");
			return;
		}
		try {
			PrintWriter pOut = new PrintWriter(sock.getOutputStream(), true);
			pOut.println(command);
			addToConsole("[  Sent  ]: " + command);
		} catch (IOException e) {
			System.err.println(e.getMessage());
			e.printStackTrace();
		}
	}
	
	/**
	 * Adds a message to the console log
	 * @param message
	 */
	private void addToConsole(String message) {
		synchronized (messageLog) {
			messageLog.add(message);
			if(message.length() > Settings.LOG_SIZE) messageLog.remove(0);
		}
		if(console != null) console.update();
	}
	
	/**
	 * Brings up the console viewer
	 */
	public void showConsole() {
		if(console == null) {
			console = new ConnectionConsole(messageLog, this);
		}
		else {
			console.setVisible(true);
		}
	}

	/**
	 * Getter for playerName.
	 * @return playerName
	 */
	public String getPlayerName() {
		return playerName;
	}
	
	/**
	 * Method to subscribe to a server game.
	 * @param name
	 */
	public void subscribeGame(String name) {
		sendCommand("subscribe " + name);
	}
	
	/**
	 * Method to challenge a player on the server.
	 * @param opponent
	 * @param gameType
	 */
	public void challengePlayer(String opponent, String gameType) {
		sendCommand("challenge \"" + opponent + "\" \"" + gameType + "\"");
	}
	
	/**
	 * Accept or decline a challenge, if accept; cancel all other potential challenges and send an 'accept' message to the server
	 * @param accept/decline
	 * @param challengeInt
	 */
	public void challengeResponse(boolean accept, int challengeInt) {
		if(accept) {
			sendCommand("challenge accept " + challengeInt);
			challenges.clear();
		}
		else {
			challenges.remove(challengeInt);
		}
	}
	
	
	/**
	 * Method to send a move to the server.
	 * @param move
	 */
	public void makeMove(String move) {
		sendCommand("move " + move);
	}
	
	/**
	 * Method to connect to a server.
	 * Starts a thread with a ConnectionHandler to listen for incoming messages.
	 * @param server
	 * @param username
	 * @return boolean
	 */
	public boolean connect(String server, String username) {
		try {
			sock = new Socket(server, 7789);
			status = true;
			sendCommand("login " + username);
			playerName = username;
			thread = new Thread(this);
			thread.start();
			playerCheck = new PlayerCheck();
			playerListThread = new Thread(playerCheck);
			playerListThread.start();
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	/**
	 * Method to forfeit a match.
	 */
	public void forfeit() {
		sendCommand("forfeit");
	}
	
	/**
	 * Method to disconnect.
	 */
	public void disconnect() {
		if(!thread.isInterrupted())	thread = null;
		if(!playerListThread.isInterrupted()) playerListThread = null;
		if(console != null) console.dispose();
		
		if(status && sock.isConnected() && !sock.isClosed()) {
			try {
				sendCommand("logout");
				status = false;
				Thread.sleep(200);
				sock.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
	
	/**
	 * Method to ask the server to send the gamelist.
	 */
	public void getGameList() {
		sendCommand("get gamelist");
	}
	
	@Override
	public void run() {
		InputStream input;
		try {
			input = sock.getInputStream();
			BufferedReader in = new BufferedReader(new InputStreamReader(input));
			
			String line;
			while((line = in.readLine()) != null) {
				addToConsole("[Received]: " + line);
				if(!status) break;
				
				if(line.equals("ERR Duplicate name exists")) {
					client.disconnect("Another player using this name is already connected");
				}
				else if(line.startsWith("SVR GAMELIST ")) {
					String cmd = line.substring(13);
					String[] games = readArray(cmd);
					if(games == null) games = new String[]{};
					client.updateGameList(games);
				}
				else if(line.startsWith("SVR GAME MATCH ")) {
					String cmd = line.substring(15);
					HashMap<String, String> data = readMap(cmd);
					gameWindow = client.createNetworkGameWindow(data.get("GAMETYPE"), playerName);
					gameWindow.start(data);
				}
				else if(line.startsWith("SVR GAME YOURTURN ")) {
					gameWindow.canMove(true);
					gameWindow.updateTimer();
				}
				else if(line.startsWith("SVR GAME MOVE ")) {
					String cmd = line.substring(14);
					HashMap<String, String> data = readMap(cmd);
					gameWindow.processMove(data);
				}
				else if(line.startsWith("SVR GAME LOSS ") || line.startsWith("SVR GAME WIN ") || line.startsWith("SVR GAME DRAW ")) {
					String result = line.split(" ")[2];
					String cmd = getCmdData(line);
					HashMap<String, String> data = readMap(cmd);
					gameWindow.gameEnded(result, data.get("COMMENT"));
					client.deselectGame();
				}
				else if(line.startsWith("SVR PLAYERLIST ")) {
					String cmd = getCmdData(line);
					String[] data = readArray(cmd);
					playerCheck.dataHandler(data);
				}
				else if(line.startsWith("SVR GAME CHALLENGE CANCELLED ")) {
					String cmd = getCmdData(line);
					HashMap<String, String> data = readMap(cmd);
					int challengeInt = Integer.parseInt(data.get("CHALLENGENUMBER"));
					if(challenges.containsKey(challengeInt)) {
						challenges.get(challengeInt).dispose();
						challenges.remove(challengeInt);
					}
				}
				else if(line.startsWith("SVR GAME CHALLENGE ")) {
					String cmd = getCmdData(line);
					HashMap<String, String> data = readMap(cmd);
					int challengeInt = Integer.parseInt(data.get("CHALLENGENUMBER"));
					String challenger = data.get("CHALLENGER");
					String gametype = data.get("GAMETYPE");
					
					JFrame window = client.processChallenge(challenger, gametype, challengeInt);
					challenges.put(challengeInt, window);
				}
			}
		} catch (Exception e) {
			//System.out.println("[Stopped listening] " + e.getMessage());
		}
	}
	
	/**
	 * Method to read the information send from a server in a String
	 * and put the information in an Array.
	 * @param s
	 * @return Array
	 */
	private String[] readArray(String s) {
		if(s.startsWith("[\"") && s.endsWith("\"]")) {
			String txt = s.substring(2, s.length() - 2);
			String[] r = txt.split("\", \"");
			return r;
		}
		return null;
	}
	
	/**
	 * Method to read the information send from a server in a String
	 * and put the information in a HashMap.
	 * @param s
	 * @return HashMap
	 */
	public HashMap<String, String> readMap(String s) {
		HashMap<String, String> map = new HashMap<String, String>();
		if(s.startsWith("{") && s.endsWith("\"}")) {
			String txt = s.substring(1, s.length() - 2);
			String[] blocks = txt.split("\", ");
			String[] keyValue;
			for(String str : blocks) {
				keyValue = str.split(": \"");
				map.put(keyValue[0], keyValue[1]);
			}
			return map;
		}
		return null;
	}
	
	/**
	 * Method to get the server String without the brackets.
	 * @param str
	 * @return
	 */
	private String getCmdData(String str) {
		int pos;
		if((pos = str.indexOf("{")) >= 0) {
			return str.substring(pos);
		}
		else if((pos = str.indexOf("[")) >= 0) {
			return str.substring(pos);
		}
		return str;
	}
	
	/**
	 * Method to check for players on the server and update the player list in the client.
	 * @author Wim, Mart, Bas, Jurrian
	 *
	 */
	private class PlayerCheck implements Runnable {
		private int lastReceivedAt = 0;
		
		public void dataHandler(String[] data) {
			lastReceivedAt = (int) (System.currentTimeMillis() / 1000);
			client.updatePlayerList(data);
		}
		
		@Override
		public void run() {
			try {
				while(true) {
					if(!status) break;
					
					int currentTime = (int) (System.currentTimeMillis() / 1000);
					if(lastReceivedAt != 0 && lastReceivedAt < (currentTime - 6)) {
						// No reponse has been received in 5 seconds, we're probably disconnected
						status = false;
						client.disconnect("Connection to server was lost");
					}
					else if(lastReceivedAt == 0) {
						lastReceivedAt = 1;
					}
					// Check for new players every 5 seconds
					sendCommand("get playerlist");
					Thread.sleep(2500);
				}
			}
			catch(Exception e) {}
		}
	}
}
