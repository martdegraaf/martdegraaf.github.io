package gameclient;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

public class ConnectionConsole extends JFrame implements ActionListener {
	
	/**
	 * Gives a view of the messages being sent back and forth through the network connection
	 */
	private static final long serialVersionUID = -5730338148292474179L;
	private final ArrayList<String> messageLog;
	private final ConnectionHandler connectionHandler;
	private JScrollPane scrollPanel;
	private JTextArea logWindow;
	private final JTextField commandTxt;
	private final JButton commandBtn;
	
	// Filters
	private JCheckBox checkboxOk;
	private JCheckBox checkboxPlayerList;
	private JCheckBox checkboxErr;
	private JCheckBox checkboxGame;
	
	public ConnectionConsole(ArrayList<String> messageLog, ConnectionHandler connectionHandler) {
		this.messageLog = messageLog;
		this.connectionHandler = connectionHandler;
		
		// the components we need
		logWindow = new JTextArea();
		logWindow.setFont(new Font("Courier New", Font.PLAIN, 10));
		logWindow.setEditable(false);
		
		//logWindow.set
		scrollPanel = new JScrollPane(logWindow, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		scrollPanel.setPreferredSize(new Dimension(500, 250));
		commandTxt = new JTextField();
		commandBtn = new JButton("Send command");
		buildGUI();
		
		setTitle("Connection log");
		setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
		update();
		pack();
		setLocationRelativeTo(null);
		setResizable(false);
		setVisible(true);
	}
	
	/**
	 * Builds the GUI
	 */
	private void buildGUI() {
		commandBtn.addActionListener(this);
		
		JPanel commandPanel = new JPanel();
		commandPanel.setLayout(new BorderLayout(5, 5));
		commandPanel.add(filterPanel(), BorderLayout.NORTH);
		commandPanel.add(commandTxt, BorderLayout.CENTER);
		commandPanel.add(commandBtn, BorderLayout.EAST);
		
		JPanel container = new JPanel();
		container.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
		container.setLayout(new BorderLayout(5, 5));
		
		container.add(scrollPanel, BorderLayout.CENTER);
		container.add(commandPanel, BorderLayout.SOUTH);
		
		add(container);
	}
	
	/**
	 * Creates a panel that allows the user to filter some common types of messages
	 * @return panel containing checkboxes
	 */
	private JPanel filterPanel() {
		JPanel panel = new JPanel(new FlowLayout(SwingConstants.NORTH_WEST, 5, 5));
		JLabel filterTitle = new JLabel("Filter:  ");
		filterTitle.setFont(filterTitle.getFont().deriveFont(14f));
		panel.add(filterTitle);
		checkboxOk = new JCheckBox("OK");
		checkboxErr = new JCheckBox("Error");
		checkboxPlayerList = new JCheckBox("Player list");
		checkboxGame = new JCheckBox("Game");
		panel.add(checkboxOk);
		panel.add(checkboxErr);
		panel.add(checkboxPlayerList);
		panel.add(checkboxGame);
		return panel;
	}
	
	/**
	 * Updates the textfield
	 */
	public void update() {
		String text = "";
		synchronized(messageLog) {
			for(String message : messageLog) {
				if(checkboxOk.isSelected() && message.equals("[Received]: OK")) continue;
				if(checkboxErr.isSelected() && message.startsWith("[Received]: ERR")) continue;
				if(checkboxPlayerList.isSelected() && message.toLowerCase().contains("playerlist")) continue;
				if(checkboxGame.isSelected() && (message.startsWith("[Received]: SVR GAME") || message.startsWith("[  Sent  ]: move"))) continue;
				if(text.length() > 0) text += "\n";
				text += message;
			}
		}
		if(!logWindow.getText().equals(text)){
			logWindow.setText(text);
			logWindow.setCaretPosition(logWindow.getDocument().getLength());
		}
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// Allow the user to manually send commands also
		String message = commandTxt.getText().trim();
		if(message.length() > 0) {
			connectionHandler.sendCommand(message);
		}
		
	}
	
}
