package gameclient;

import gameclient.window.GameWindowLocal;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashMap;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import model.Settings;

/**
 * This class is a JDialog that pops up when the user chooses to play a local game.
 * The user has to specify his own username and the username of the player he is playing against.
 * He or she also has to specify if the opponent is a human or computer.
 * @author Mart, Wim, Bas, Jurrian
 *
 */
public class LocalGameOpponentPicker extends JDialog implements ActionListener {
	private final String gameName;
	private final int playerType;
	private final ExtGameModuleLoader loader;
	
	private final JTextField playerOneName = new JTextField(Settings.NAME);
	private final JTextField playerTwoName = new JTextField("Beta");
	
	private final JButton startVsPlayer = new JButton("Human");
	private final JButton startVsAI = new JButton("Computer");
	
	public LocalGameOpponentPicker(String gameName, int playerType, ExtGameModuleLoader loader, GameClient client) {
		this.gameName = gameName;
		this.playerType = playerType;
		this.loader = loader;
		
		add(createUI());
		
		setTitle("Set up local game");
		setModal(true);
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		pack();
		setResizable(false);
		setLocationRelativeTo(client); // center window
		setVisible(true);
	}
	
	/**
	 * Create GUI.
	 * @return JPanel
	 */
	private JPanel createUI() {
		JPanel container = new JPanel();
		container.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
		container.setLayout(new BorderLayout(5, 5));
		
		container.add(getTopPanel(), BorderLayout.NORTH);
		container.add(getBottomPanel(), BorderLayout.CENTER);
		
		return container;
	}
	
	/**
	 * Create the playerOne input panel.
	 * @return
	 */
	private JPanel getTopPanel() {
		JPanel container = new JPanel();
		container.setLayout(new BorderLayout(5,5));
		container.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, Color.DARK_GRAY));
		
		JPanel inner = new JPanel();
		inner.setLayout(new BorderLayout(5,5));
		inner.setBorder(BorderFactory.createEmptyBorder(0, 0, 5, 0));
		
		inner.add(new JLabel("Your name:"), BorderLayout.NORTH);
		inner.add(playerOneName, BorderLayout.CENTER);
		
		container.add(inner, BorderLayout.CENTER);
		return container;
	}
	
	/**
	 * Create the playerTwo input panel.
	 * @return
	 */
	private JPanel getBottomPanel() {
		JPanel container = new JPanel();
		container.setLayout(new BorderLayout(5,5));
		
		JLabel title = new JLabel("Play against:");
		title.setFont(title.getFont().deriveFont(16f));
		
		JPanel namePanel = new JPanel();
		namePanel.setLayout(new BorderLayout(5, 5));
		namePanel.add(new JLabel("Name:"), BorderLayout.NORTH);
		namePanel.add(playerTwoName, BorderLayout.CENTER);
		
		JPanel nameAndTitlePanel = new JPanel();
		nameAndTitlePanel.setLayout(new BorderLayout(5, 5));
		nameAndTitlePanel.add(title, BorderLayout.NORTH);
		nameAndTitlePanel.add(namePanel, BorderLayout.CENTER);
		
		JPanel buttonPanel = new JPanel();
		buttonPanel.setLayout(new GridLayout(1, 2, 5, 5));
		buttonPanel.add(startVsPlayer);
		buttonPanel.add(startVsAI);
		startVsAI.addActionListener(this);
		startVsPlayer.addActionListener(this);
		
		container.add(nameAndTitlePanel, BorderLayout.NORTH);
		container.add(buttonPanel, BorderLayout.CENTER);
		
		return container;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		dispose();
		Object source = e.getSource();
		GameWindowLocal gameWindow;
		Settings.NAME = playerOneName.getText();
		if(source == startVsPlayer) {
			gameWindow = new GameWindowLocal(gameName, Settings.NAME, playerType, playerTwoName.getText(), Settings.HUMAN, loader);
		}
		else {
			gameWindow = new GameWindowLocal(gameName, Settings.NAME, playerType, playerTwoName.getText(), Settings.COMPUTER, loader);
		}
		HashMap<String, String> data = new HashMap<String, String>();
		data.put("PLAYERTOMOVE", playerOneName.getText());
		data.put("OPPONENT", playerTwoName.getText());
		data.put("GAMETYPE", gameName);
		gameWindow.start(data);
	}
	
}
