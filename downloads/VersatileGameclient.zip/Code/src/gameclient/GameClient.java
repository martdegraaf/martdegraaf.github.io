package gameclient;

import gameclient.window.GameWindowNetwork;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Enumeration;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.AbstractButton;
import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JToggleButton;
import javax.swing.ListModel;
import javax.swing.SwingConstants;
import javax.swing.border.BevelBorder;
import javax.swing.border.Border;

import model.Settings;

/**
 * GameClient is the GUI the user gets to see when the application is run.
 * The user can choose between a local or a network game.
 * The user can choose to subscribe to a game or to challenge another player to a game.
 * @author Wim, Mart, Bas, Jurrian
 *
 */
public class GameClient extends JFrame implements ActionListener
{
	// Connection handler
	private final ConnectionHandler connectionHandler = new ConnectionHandler(this);
	
	// Used to get our available games and load those games
	private static final ExtGameModuleLoader loader = new ExtGameModuleLoader(new File("gamemodules"));
	
	// Used for settings
	private final ButtonGroup envButtons = new ButtonGroup();
	private final ButtonGroup playerButtons = new ButtonGroup();
	// Used for games
	private final ButtonGroup gameButtons = new ButtonGroup();
	
	// Label for showing if we're connected
	private JLabel connectionStatus = new JLabel("Connected");
	
	// Buttons, to use for checking source in action listener
	private JToggleButton envNetworkButton;
	private JToggleButton envLocalButton;
	private JToggleButton playerHumanButton;
	private JToggleButton playerComputerButton;
	
	// For the playerlist
	private JPanel playerPanel;
	private JPanel containerPanel;			// So we can toggle
	private JList<String> playerList;
	private JToggleButton challengeButton;
	
	// Status
	private JLabel statusText = new JLabel("Ready");
	
	// Menu
	private JMenuItem difficultyItem;
	private JMenuItem networkLogItem;
	private JMenuItem exitItem;
	private JMenuItem aboutItem;
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Settings.initialize();
		new GameClient();
	}
	
	public GameClient() {
		setTitle("Versatile Game client");
		// Build Gui
		add(buildGUI());
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		pack();
		setResizable(false);
		setLocationRelativeTo(null); // center window
		setVisible(true);
	}
	
	/**
	 * Build GUI
	 * @return JPanel
	 */
	private JPanel buildGUI() {
		containerPanel = new JPanel();
		containerPanel.setLayout(new BorderLayout(5, 5));
		
		JPanel mainPanel = new JPanel();
		
		mainPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 5, 10));
		mainPanel.setLayout(new GridLayout(0, 2, 10, 10));
		
		mainPanel.add(buildGameListPanel());
		mainPanel.add(buildSettingsPanel());
		
		containerPanel.add(mainPanel, BorderLayout.CENTER);
		containerPanel.add(createStatusPanel(), BorderLayout.SOUTH);
		
		buildPlayerListPanel();
		addMenu();
		
		return containerPanel;
	}
	
	/**
	 * Method to toggle the playerPanel.
	 * The playerPanel holds the online players.
	 * @param on
	 */
	private void togglePlayerPanel(boolean on) {
		containerPanel.remove(playerPanel);
		if(on) {
			containerPanel.add(playerPanel, BorderLayout.EAST);
		}
		
		setResizable(true);
		pack();
		setResizable(false);
	}
	
	/**
	 * Build the JPanel where the gamelist is shown.
	 * @return JPanel
	 */
	private JPanel buildGameListPanel() {
		JPanel listPanel = new JPanel();
		listPanel.setLayout(new GridLayout(0, 1, 5, 5));
		listPanel.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
		listPanel.setOpaque(false);
		
		ArrayList<String> gameList = loader.getGameTypeList();
		
		int buttonHeight = 30;
		int listHeight = gameList.size() * buttonHeight + ((gameList.size() - 1) * 5);
		int listContainerHeight = 150;
		int listContainerWidth = 250;
		int buttonWidth = listContainerWidth - 10;
		if(listHeight + 20 >= listContainerHeight){
			buttonWidth -= 20;
			listHeight += 20;
		}
		
		for(String game : gameList) {
			JToggleButton button = new JToggleButton(game);
			button.addActionListener(this);
			button.setPreferredSize(new Dimension(buttonWidth, buttonHeight));
			gameButtons.add(button);
			listPanel.add(button);
		}
		
		JPanel listContainer = new JPanel();
		listContainer.add(listPanel);
		listContainer.setAutoscrolls(true);
		listContainer.setPreferredSize(new Dimension(buttonWidth, listHeight));
		listContainer.setOpaque(true);
		listContainer.setBackground(Color.BLACK);
		
		JScrollPane scrollpane = new JScrollPane(listContainer);
		scrollpane.setPreferredSize(new Dimension(listContainerWidth, listContainerHeight));
		
		JPanel innerContainer = new JPanel();
		innerContainer.setBorder(BorderFactory.createBevelBorder(BevelBorder.LOWERED));
		innerContainer.setLayout(new BorderLayout(5, 5));
		innerContainer.add(scrollpane, BorderLayout.CENTER);
		
		JLabel title = new JLabel("Games:");
		title.setFont(title.getFont().deriveFont(16f));
		
		JPanel container = new JPanel();
		container.setLayout(new BorderLayout());
		container.add(title, BorderLayout.NORTH);
		container.add(innerContainer, BorderLayout.CENTER);
		
		return container;
	}
	
	/**
	 * Build the JPanel where the settings are shown.
	 * @return JPanel
	 */
	private JPanel buildSettingsPanel() {
		JPanel innerContainer = new JPanel();
		innerContainer.setLayout(new GridLayout(2, 1, 10, 10));
		innerContainer.add(buildEnvSettingsPanel());
		innerContainer.add(buildPlayerSettingsPanel());
		
		JLabel title = new JLabel("Settings:");
		title.setFont(title.getFont().deriveFont(16f));
		
		JPanel container = new JPanel();
		container.setLayout(new BorderLayout());
		container.add(title, BorderLayout.NORTH);
		container.add(innerContainer, BorderLayout.CENTER);
		return container;
	}
	
	/**
	 * Build JPanel where the "Human" and "Computer" settings are shown.
	 * @return JPanel
	 */
	private JPanel buildPlayerSettingsPanel() {
		JLabel envTitle = new JLabel("Player:");
		JPanel playerButtonPanel = new JPanel();
		playerButtonPanel.setLayout(new GridLayout(1, 2, 5, 5));
		
		playerHumanButton = new JToggleButton("Human"); 
		playerComputerButton = new JToggleButton("Computer");
		playerButtonPanel.add(playerHumanButton);
		playerButtonPanel.add(playerComputerButton);
		playerButtons.add(playerHumanButton);
		playerButtons.add(playerComputerButton);
		playerHumanButton.setSelected(true);
		
		JPanel playerPanel = new JPanel();
		playerPanel.setLayout(new BorderLayout(10, 10));
		playerPanel.add(envTitle, BorderLayout.NORTH);
		playerPanel.add(playerButtonPanel, BorderLayout.CENTER);
		addPaddedBevel(playerPanel);
		return playerPanel;
	}
	
	/**
	 * Build JPanel where the user can choose between "Network" and "Local"
	 * @return
	 */
	private JPanel buildEnvSettingsPanel() {
		JLabel envTitle = new JLabel("Environment:");
		connectionStatus.setForeground(Color.GREEN.darker().darker());
		connectionStatus.setHorizontalAlignment(SwingConstants.RIGHT);
		connectionStatus.setVisible(false);
		
		JPanel labelPanel = new JPanel();
		labelPanel.setLayout(new GridLayout(1, 2));
		labelPanel.add(envTitle);
		labelPanel.add(connectionStatus);
		
		JPanel envButtonPanel = new JPanel();
		envButtonPanel.setLayout(new GridLayout(1, 2, 5, 5));
		
		envLocalButton = new JToggleButton("Local"); 
		envNetworkButton = new JToggleButton("Network");
		envLocalButton.addActionListener(this);
		envNetworkButton.addActionListener(this);
		envButtonPanel.add(envLocalButton);
		envButtonPanel.add(envNetworkButton);
		envButtons.add(envLocalButton);
		envButtons.add(envNetworkButton);
		envLocalButton.setSelected(true);
		
		JPanel environmentPanel = new JPanel();
		environmentPanel.setLayout(new BorderLayout(10, 10));
		environmentPanel.add(labelPanel, BorderLayout.NORTH);
		environmentPanel.add(envButtonPanel, BorderLayout.CENTER);
		addPaddedBevel(environmentPanel);
		return environmentPanel;
	}
	
	/**
	 * Build JPanel that shows the online players.
	 */
	private void buildPlayerListPanel() {
		playerPanel = new JPanel();
		playerPanel.setLayout(new BorderLayout(0, 0));
		playerPanel.setBorder(BorderFactory.createEmptyBorder(10, 0, 5, 10));
		playerPanel.setPreferredSize(new Dimension(120, 150));
		playerList = new JList<String>();
		addPaddedBevel(playerList);
		JScrollPane scrollPlayerList = new JScrollPane(playerList);
		
		JLabel title = new JLabel("Players:");
		title.setFont(title.getFont().deriveFont(16f));
		
		challengeButton = new JToggleButton("Challenge");
		challengeButton.addActionListener(this);
		
		playerPanel.add(title, BorderLayout.NORTH);
		playerPanel.add(scrollPlayerList, BorderLayout.CENTER);
		playerPanel.add(challengeButton, BorderLayout.SOUTH);
	}
	
	/**
	 * Build JPanel that holds the connection status.
	 * @return JPanel
	 */
	private JPanel createStatusPanel() {
		JPanel statusPanel = new JPanel();
		statusPanel.setLayout(new GridLayout());
		statusPanel.setOpaque(true);
		statusPanel.setBackground(new Color(220, 220, 220));
		statusPanel.setBorder(BorderFactory.createEmptyBorder(2, 2, 2, 2));
		statusPanel.add(statusText);
		statusText.setHorizontalAlignment(SwingConstants.LEFT);
		JPanel borderPanel = new JPanel();
		borderPanel.setLayout(new GridLayout());
		borderPanel.setBorder(BorderFactory.createMatteBorder(1, 0, 0, 0, new Color(150, 150, 150)));
		borderPanel.add(statusPanel);
		return borderPanel;
	}
	
	/**
	 * Add a difficulty settings menu to the GUI
	 */
	private void addMenu() {
		JMenuBar menu = new JMenuBar();
		JMenu fileMenu = new JMenu("File");
		difficultyItem = new JMenuItem("Difficulty");
		networkLogItem = new JMenuItem("Show network log");
		exitItem = new JMenuItem("Exit");
		
		JMenu helpMenu = new JMenu("Help");
		aboutItem = new JMenuItem("About");
		
		fileMenu.add(difficultyItem);
		fileMenu.add(networkLogItem);
		fileMenu.add(exitItem);
		helpMenu.add(aboutItem);
		
		menu.add(fileMenu);
		menu.add(helpMenu);
		
		difficultyItem.addActionListener(this);
		networkLogItem.addActionListener(this);
		exitItem.addActionListener(this);
		aboutItem.addActionListener(this);
		
		this.setJMenuBar(menu);
	}
	
	public void setStatus(String text) {
		statusText.setText(text);
	}
	
	/**
	 * Adds padding and a bevel to your panel
	 * @param your panel
	 * @return modified panel
	 */
	private void addPaddedBevel(JComponent original) {
		Border a = BorderFactory.createEmptyBorder(5, 5, 5, 5);
		Border b = BorderFactory.createBevelBorder(BevelBorder.LOWERED);
		Border border = BorderFactory.createCompoundBorder(b, a);
		original.setBorder(border);
	}
	
	/**
	 * Method to create a GameWindowNetwork bases on the gameType and userName.
	 * @param gameType
	 * @param userName
	 * @return
	 */
	public GameWindowNetwork createNetworkGameWindow(String gameType, String userName) {
		GameWindowNetwork gameWindow;
		gameWindow = new GameWindowNetwork(gameType, userName, getPlayerSetting(), loader, connectionHandler);
		gameWindow.setLocation(this.getLocation().x, this.getLocation().y);
		return gameWindow;
	}
	
	/**
	 * Update the gamelist shown in the client GUI.
	 * @param games
	 */
	public void updateGameList(String[] games) {
		if(games == null) {
			gameButtons.clearSelection();
		}
		
		Enumeration<AbstractButton> buttons = gameButtons.getElements();
		while(buttons.hasMoreElements()) {
			AbstractButton b = buttons.nextElement();
			if(games == null) {
				b.setEnabled(true);
			}
			else {
				b.setEnabled(false);
				for(String g : games) {
					if(b.getText().equals(g)) {
						b.setEnabled(true);
					}
				}
			}
		}
	}
	
	/**
	 * Update the playerlist shown in the client GUI.
	 * @param players
	 */
	public void updatePlayerList(String[] players) {
		ListModel<String> currentModel = playerList.getModel();
		String[] currentPlayers = new String[currentModel.getSize()];
		for(int i = 0; i < currentModel.getSize(); i++) {
			currentPlayers[i] = currentModel.getElementAt(i);
		}
		if(Arrays.equals(currentPlayers, players)) return;
		
		String selection = playerList.getSelectedValue();
		playerList.setListData(players);
		if(selection != null) playerList.setSelectedValue(selection, false);
	}
	
	/**
	 * Method to set the status to "Connected".
	 */
	public void connectionSuccessful() {
		setStatus("Connected");
		connectionStatus.setVisible(true);
		togglePlayerPanel(true);
	}

	/**
	 * Method to disconnect and set the status to "Disconnected".
	 * @param reason
	 */
	public void disconnect(String reason) {
		setStatus("Disconnecting");
		connectionHandler.disconnect();
		envButtons.setSelected(envLocalButton.getModel(), true);
		updateGameList(null);
		connectionStatus.setVisible(false);
		togglePlayerPanel(false);
		setStatus("Disconnected");
		if(reason != null) {
			JOptionPane.showMessageDialog(this, reason);
		}
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		Object source = e.getSource();
		
		if(source == envNetworkButton) {
			if(!isConnected()) {
				new ConnectionWindow(this);
				if(!isConnected()) {
					// User closed the connection window / no succesful connection was made 
					envLocalButton.setSelected(true);
				}
			}
		}
		else if(source == envLocalButton) {
			disconnect(null);
		}
		else if(source == challengeButton) {
			if(challengeButton.isSelected()) {
				gameButtons.clearSelection();
				setStatus("Challenge mode enabled. If you've selected an opponent, click the game you wish to challenge this opponent to.");
			}
			else {
				setStatus("Challenge mode disabled. Choose the game you wish to subscribe to.");
			}
		}
		else if(source == difficultyItem) {
			
			JToggleButton hard = new JToggleButton("Hard");
			if(Settings.DIFFICULTY == Settings.HARD) hard.setSelected(true);
			
			JToggleButton medium = new JToggleButton("Medium");
			if(Settings.DIFFICULTY == Settings.MEDIUM) medium.setSelected(true);
			
			JToggleButton easy = new JToggleButton("Easy");
			if(Settings.DIFFICULTY == Settings.EASY) easy.setSelected(true);
			
			hard.addActionListener(new ActionListener() {
			    @Override
			    public void actionPerformed(ActionEvent evt) { Settings.DIFFICULTY = Settings.HARD; Settings.save(); }
			});
			medium.addActionListener(new ActionListener() {
			    @Override
			    public void actionPerformed(ActionEvent evt) { Settings.DIFFICULTY = Settings.MEDIUM; Settings.save(); }
			});
			easy.addActionListener(new ActionListener() {
			    @Override
			    public void actionPerformed(ActionEvent evt) { Settings.DIFFICULTY = Settings.EASY; Settings.save(); }
			});
			
			String[] difficulty = new String[]{ "Easy", "Medium", "Hard" };
			new DialogWindow(this, "Change computer difficulty", "Current difficulty: " + difficulty[Settings.DIFFICULTY], new JToggleButton[]{ easy, medium, hard });
		}
		else if(source == networkLogItem) {
			if(isConnected()) {
				connectionHandler.showConsole();
			}
			else {
				JOptionPane.showMessageDialog(this, "This option is to show the network log, it only works when you are connected to a server.");
			}
		}
		else if(source == exitItem) {
			System.exit(0);
		}
		else if(source == aboutItem) {
			JOptionPane.showMessageDialog(this, "Versatile Game Client\n\nProject by team Alpha\nAKA Deep Glue\n\nWim Barelds, Mart de Graaf,\n Jurrian Heikes, Bas Helder.");
		}
		else {
			Enumeration<AbstractButton> buttons = gameButtons.getElements();
			while(buttons.hasMoreElements()) {
				AbstractButton b = buttons.nextElement();
				if(b == source) {
					if(getEnvSetting() == Settings.NETWORK) {
						if(getGameRequestType() == Settings.CHALLENGE) {
							String opponent = playerList.getSelectedValue();
							if(opponent == null) {
								// No opponent selected, Alert!
								JOptionPane.showMessageDialog(this, "No opponent was selected to be challenged");
							}
							else if(opponent.equals(connectionHandler.getPlayerName())) {
								// Alert!
								JOptionPane.showMessageDialog(this, "You can not challenge yourself");
							}
							else {
								// Challenge
								connectionHandler.challengePlayer(opponent, b.getText());
								setStatus("You have challenged " + opponent + " to a game of " + b.getText());
							}
							gameButtons.clearSelection();
						}
						else {
							connectionHandler.subscribeGame(b.getText());
							setStatus("Subscribed to game, waiting for other players.");
						}
					}
					else {
						gameButtons.clearSelection();
						new LocalGameOpponentPicker(b.getText(), getPlayerSetting(), loader, this);
					}
				}
			}
		}
	}
	
	/**
	 * Getter for the connectionHandler.
	 * @return connectionHandler
	 */
	protected ConnectionHandler getConnectionHandler() {
		return connectionHandler;
	}
	
	/**
	 * Check if the client is connected.
	 * @return boolean
	 */
	public boolean isConnected() {
		return connectionStatus.isVisible();
	}
	
	/**
	 * Method to check if the user wants to challenge someone,
	 * or wants to subscribe to a game.
	 * @return int
	 */
	public int getGameRequestType() {
		if(challengeButton.isSelected()) {
			return Settings.CHALLENGE;
		}
		return Settings.SUBSCRIBE;
	}
	
	/**
	 * Method to check which match enviroment the user has chosen.
	 * @return int
	 */
	public int getEnvSetting() {
		if(envLocalButton.isSelected()) return Settings.LOCAL;
		else return Settings.NETWORK;
	}
	
	/**
	 * Method to check if the user has selected to play as human or as computer.
	 * @return
	 */
	public int getPlayerSetting() {
		if(playerHumanButton.isSelected()) return Settings.HUMAN;
		else return Settings.COMPUTER;
	}
	
	/**
	 * Method to clear the chosen gameButton.
	 */
	public void deselectGame() {
		gameButtons.clearSelection();
	}

	/**
	 * Method to process a challenge received from another player trough the server.
	 * @param challenger
	 * @param gameType
	 * @param challengeInt
	 */
	public JFrame processChallenge(final String challenger, final String gameType, final int challengeInt) {
		JButton yes = new JButton("Yes");
		yes.addActionListener(new ActionListener() {
		    @Override
		    public void actionPerformed(ActionEvent evt) {
		        connectionHandler.challengeResponse(true, challengeInt);
		    }
		});
		JButton no = new JButton("No");
		yes.addActionListener(new ActionListener() {
		    @Override
		    public void actionPerformed(ActionEvent evt) {
		        connectionHandler.challengeResponse(false, challengeInt);
		    }
		});
		String message =  challenger + " has challenged you to a game of " + gameType + "\n" +
			    "Would you like to accept this challenge?";
		
		return new DialogWindow(this, "You have been challenged", message, new JButton[] { yes, no });
	}
}
