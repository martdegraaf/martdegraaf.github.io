package game.connectfour;

public class Game {

	public static final String GAME_TYPE = "ConnectFourGame";

}
