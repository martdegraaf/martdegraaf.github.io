package game.connectfour;

import java.awt.Color;
import java.awt.Component;
import java.util.HashMap;

import nl.hanze.t23i.gamemodule.extern.AbstractGameModule;
/**
 * Class that represents a Connect four game. Also known in dutch as "Vier op 'n rij".
 * 
 * @author Mart de Graaf, Jurrian Heikes, Bas Helder en Wim Barelds
 *
 */
public class ConnectFourGame extends AbstractGameModule {

	public static final String GAME_TYPE = Game.GAME_TYPE;
	
	public static final int PLAYER_ONE    = 0; 
	public static final int PLAYER_TWO    = 1; 
	public  static final int EMPTY        = 2;
	
	private GameView gameView;
	protected String nextPlayer;
	private String moveDetails;
	private HashMap<String, Integer> playerResults;
	
	protected int [ ] [ ] board = new int[ 7 ][ 6 ];
	public static Color playerOneColor = Color.red;
	public static Color playerTwoColor = Color.yellow;	
	
	public ConnectFourGame(String playerOne, String playerTwo) {
		super(playerOne, playerTwo);
		
		moveDetails = null;
		playerResults = new HashMap<String, Integer>();
		gameView = new GameView(playerOne, playerTwo);
		clearBoard();
	}
	
	@Override
	public void doPlayerMove(String player, String move) throws IllegalStateException {
		super.doPlayerMove(player, move);
		
		if(!nextPlayer.equals(player)) {
			matchStatus = MATCH_FINISHED;
			moveDetails = "Its not players turn";
			playerResults.put(otherPlayer(player), PLAYER_WIN);
			playerResults.put(player, PLAYER_LOSS);
			return;
		}
		
		int row = Integer.parseInt(move);
		
		
		//if position is not empty.. It is an illegal move
		if(row < 0 || row > board.length){
			illegalPlayerMove(player);
			return;
		}
		if(player.equals(playerOne)){
			placeOnBoard(row, PLAYER_ONE);
			
		}else{
			placeOnBoard(row, PLAYER_TWO);
		}
		
		
		if(fourOnARow(player)){
			matchStatus = MATCH_FINISHED;
			moveDetails = "Geen zetten meer mogelijk";
			playerResults.put(player, PLAYER_WIN);
			playerResults.put(otherPlayer(player), PLAYER_LOSS);
		}else if(boardIsFull()){
			matchStatus = MATCH_FINISHED;
			moveDetails = "Geen zetten meer mogelijk";
			playerResults.put(player, PLAYER_DRAW);
			playerResults.put(otherPlayer(player), PLAYER_DRAW);
			
		}else{
			//nothing else matters
			moveDetails = "Jij bent";
			nextPlayer();
		}
		gameView.updateField(fieldToString());
		
	}
	
	private void illegalPlayerMove(String player) {
		matchStatus = MATCH_FINISHED;
		moveDetails = "Illegal move";
		playerResults.put(player, PLAYER_LOSS);
		playerResults.put(otherPlayer(player), PLAYER_WIN);
	}
	
	@Override
	public String getMatchResultComment() throws IllegalStateException {
		super.getMatchResultComment();
		
		return moveDetails;
	}

	@Override
	public int getMatchStatus() {
		return matchStatus;
	}

	@Override
	public String getMoveDetails() throws IllegalStateException {
		super.getMoveDetails();
		
		if(moveDetails == null) {
			throw new IllegalStateException("No move has been done during this match");
		}
		
		return moveDetails;
	}

	@Override
	public String getPlayerToMove() throws IllegalStateException {
		super.getPlayerToMove();
		
		return nextPlayer;
	}

	@Override
	public int getPlayerResult(String player) throws IllegalStateException {
		super.getPlayerResult(player);
		
		return playerResults.get(player);
	}
	
	@Override
	public int getPlayerScore(String player) throws IllegalStateException {
		super.getPlayerResult(player);
		
		return playerResults.get(player);
	}

	@Override
	public String getTurnMessage() throws IllegalStateException {
		super.getTurnMessage();
		
		String message = null;
		
		if(moveDetails == null) {
			message = "Leg 4 op een rij";
		} else {
			message = moveDetails;
		}
		
		return message;
	}

	@Override
	public Component getView() {
		return gameView;
	}

	@Override
	public void start() throws IllegalStateException {
		super.start();
		
		nextPlayer = playerOne;
		clearBoard();
	}
	
	private void nextPlayer() {
		nextPlayer = otherPlayer(nextPlayer);
	}
	
	protected String otherPlayer(String player) {
		return player.equals(playerOne) ? playerTwo : playerOne;
	}
	
	// Simple supporting routines
	private void clearBoard( )
	{
		for(int i = 0;i<board.length;i++){
			for(int j = 0;j<board[i].length;j++){
				board[i][j] = EMPTY;
			}
		}		
		gameView.updateField(fieldToString());
	}
	/**
	 * Checks if board is full return true
	 */
	private boolean boardIsFull( )
	{
		for(int i = 0;i<board.length;i++){
			for(int j = 0;j<board[i].length;j++){
				if(board[i][j] != PLAYER_ONE && board[i][j] != PLAYER_TWO){
					return false;
				}
			}
		}
		return true;
	}
	/**
	 * Place on board
	 */
	private void placeOnBoard(int x, int player)
	{
		for(int y = board[x].length -1;y >= 0;y--){
			if(board[x][y] == EMPTY){
				board[x][y] = player;
				break;
			}
		}
	}
	
	private boolean fourOnARow(String player){
		
		int playerInt = getPlayerInt(player);
		//verticaal
		for(int x = board.length-1; x >= 0; x--){
			for(int y = 0; y < board[x].length-3;y++){
				if(board[x][y] == playerInt &&
						board[x][y+1] == playerInt &&
						board[x][y+2] == playerInt &&
						board[x][y+3] == playerInt){
					return true;
				}
			}
		}
		//horizontaal
		for(int y = 0; y < board[0].length ; y++){
			for(int x = board.length-1; x > 2;x--){
				if(board[x][y] == playerInt &&
						board[x-1][y] == playerInt &&
						board[x-2][y] == playerInt &&
						board[x-3][y] == playerInt){
					return true;
				}
			}
		}
		//diagonaal linksonder naar rechtsboven
		for(int y = 0; y < board[0].length-3 ; y++){
			for(int x = board.length-1; x > 2;x--){
				if(board[x][y] == playerInt &&
						board[x-1][y + 1] == playerInt &&
						board[x-2][y + 2] == playerInt &&
						board[x-3][y + 3] == playerInt){
					return true;
				}
			}
		}
		
		//diagonaal rechtsonder naar linksboven
		for(int x = 0; x < board.length-3 ; x++){
			for(int y = 0; y < board[x].length-3;y++){
				if(board[x][y] == playerInt &&
						board[x+1][y + 1] == playerInt &&
						board[x+2][y + 2] == playerInt &&
						board[x+3][y + 3] == playerInt){
					return true;
				}
			}
		}
		
		return false;
	}
	
	/**
	 * Function to print board to simple text
	 * @return String
	 */
	public String fieldToString()
	{
	    String print = " |01234567\n";
	    print += "-+--------\n";
		for(int i = 0; i < board[0].length;i++){
			print += i+"|";
	    	for(int j = 0; j< board.length; j++){
	    		if(board[j][i] == PLAYER_ONE){
	    			print += 'O';
	    		}else if(board[j][i] == PLAYER_TWO){
	    			print += '8';
	    		}else{
	    			print += "-";
	    		}
	    	}
	    	print += "\n";
	    }
		return print;
	} 
	
	/**
	 * get the int of the player
	 * @param player
	 * @return
	 */
	public int getPlayerInt(String player) {
		if(player.equals(playerOne)){
			return PLAYER_ONE;
		}else{
			return PLAYER_TWO;
		}
	}
	
	public int countStones(String player){
		int count = 0;
		int intToCount = EMPTY;
		if(player.equals(playerOne)){
			intToCount = PLAYER_ONE;
		}else if(player.equals(playerTwo)){
			intToCount = PLAYER_TWO;
		}
		for(int i = 0;i<board.length;i++){
			for(int j = 0;j<board[i].length;j++){
				if(board[i][j] == intToCount){
					count++;
				}
			}
		}
		return count;
	}
}
