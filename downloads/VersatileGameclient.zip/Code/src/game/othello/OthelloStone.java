package game.othello;

import java.awt.Color;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.geom.Ellipse2D;

import javax.swing.JButton;

/**
 * This class represents a OthelloStone. It is used in the controllerView of Othello.
 * @author Mart, Wim, Bas, Jurrian
 *
 */
public class OthelloStone extends JButton {

	public static final Color BACKGROUND_COLOR = Color.green.darker().darker();
	private static final long serialVersionUID = 1L;
	
	public OthelloStone() {
		setOpaque(true);
		setEnabled(false);
		setFocusable(false);
		setBorder(null);
		setForeground(BACKGROUND_COLOR);
		setBackground(BACKGROUND_COLOR);
	}
	
	/**
	 * Set the color of the stone
	 * @param c
	 */
	public void setColor(Color c) {
		setForeground(c);
		repaint();
	}
	
	/**
	 * Paint the stone
	 */
	public void paintComponent(Graphics g) {
		setOpaque(true);
		super.paintComponent(g);
		Graphics2D g2d = (Graphics2D)g;
		int offset = (int) (this.getWidth() * 0.1);
		int size = (int) (this.getWidth() * 0.8);
		   
		Color bgColor = getForeground();
		g2d = (Graphics2D) g;
		g2d.setPaint(new GradientPaint(0, 0, bgColor, size * 2.25f, size * 2.25f, Color.GRAY, false));
		Ellipse2D.Double ellipse = new Ellipse2D.Double(offset,offset,size,size);
		g2d.fill(ellipse);
		   
		if(!bgColor.equals(BACKGROUND_COLOR)) {
			Color fgColor = Color.DARK_GRAY;
			if(bgColor.equals(Color.WHITE)) {
				fgColor = fgColor.brighter().brighter().brighter();
			}
			g2d.setColor(fgColor);
			g2d.drawOval(offset + 2, offset + 2, size - 4, size - 4);
		}
		g2d.setBackground(bgColor);
	}
}
