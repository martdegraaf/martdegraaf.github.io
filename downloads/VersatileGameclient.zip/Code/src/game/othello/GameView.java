package game.othello;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;

import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JPanel;

/**
 * View class that holds the view of OthelloGame.
 * @author Mart, Wim, Bas, Jurrian
 *
 */
public class GameView extends JPanel {

	private static final long serialVersionUID = 0L;
	
	private JPanel boardPanel;
	private OthelloStone[][] buttonGrid = new OthelloStone[8][8];
	
	public GameView(String playerOne, String playerTwo) {
		this.setLayout(new BorderLayout(5, 5));
		boardPanel = new JPanel(new GridLayout(OthelloBoard.HEIGHT, OthelloBoard.WIDTH));
		
		for(int y = 0; y < OthelloBoard.WIDTH; y++) {
			for(int x = 0; x < OthelloBoard.HEIGHT; x++) {
				OthelloStone stone = new OthelloStone();
				buttonGrid[x][y] = stone;
				
				JPanel tile = new JPanel();
				tile.setOpaque(true);
				tile.setBackground(OthelloStone.BACKGROUND_COLOR);
				tile.setLayout(new GridLayout(1,1));
				tile.add(stone);
				tile.setBorder(BorderFactory.createLineBorder(Color.BLACK));
				boardPanel.add(tile);
			}
		}
		boardPanel.setPreferredSize(new Dimension(300, 300));
		
		JPanel panel = new JPanel(new FlowLayout());
		panel.add(new JLabel("Player 1: " + playerOne));
		panel.add(new JLabel("Player 2: " + playerTwo));
		
		add(boardPanel, BorderLayout.CENTER);
		add(panel, BorderLayout.SOUTH);
		
		boardPanel.setOpaque(true);
		boardPanel.setBackground(OthelloStone.BACKGROUND_COLOR);
		setOpaque(true);
		setBackground(OthelloStone.BACKGROUND_COLOR);
		
	}
	
	/**
	 * Method to update the TextField
	 * @param text
	 */
	public void update(OthelloBoard board) {
		int[][] grid = board.getArray();
		
		for(int x = 0; x < buttonGrid.length; x++) {
			for(int y = 0; y < buttonGrid[x].length; y++) {
				OthelloStone b = buttonGrid[x][y]; 
				b.setEnabled(false);
				Color c;
				if(grid[x][y] == OthelloGame.PLAYER_ONE){ c = Color.WHITE; }
				else if(grid[x][y] == OthelloGame.PLAYER_TWO) c= Color.BLACK;
				else {
					c = OthelloStone.BACKGROUND_COLOR;
				}
				b.setColor(c);
			}
		}
	}
}
