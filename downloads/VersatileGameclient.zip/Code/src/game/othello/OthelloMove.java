package game.othello;

/**
 * This class is a Othello move.
 * It holds the coordinates of the move.
 * Is also holds the value of the move.
 * @author Mart, Wim, Bas, Jurrian
 *
 */
public class OthelloMove {
	public int x;
	public int y;
	public double value = OthelloBoard.STATE_UNKNOWN;
	
	public OthelloMove(int x, int y) {
		this.x = x;
		this.y = y;
	}
	
	/**
	 * Setter for value.
	 * @param value
	 */
	public void setValue(double value){
		this.value = value;
	}
	
	/**
	 * Setter for the value.
	 * @param value
	 */
	public void setValue(int value){
		this.value = (double) value;
	}
	
	/**
	 * Method to return the move in a String.
	 */
	public String toString() {
		return x + "," + y;
	}
	
	/**
	 * Method to return the move + value in a String
	 * @return
	 */
	public String toStringExt() {
		return toString() + ": " + value;
	}
	
	/**
	 * Method to check if another move is better than (or equal to) this one.
	 * @param move
	 * @param player
	 * @return
	 */
	public boolean isBetterThan(OthelloMove move, int player) {
		double valueA = (value <= OthelloGame.PLAYER_TWO) ? value : ((0.0 + OthelloGame.PLAYER_ONE + OthelloGame.PLAYER_TWO) / 2.0);
		double valueB = (move.value <= OthelloGame.PLAYER_TWO) ? move.value : ((0.0 + OthelloGame.PLAYER_ONE + OthelloGame.PLAYER_TWO) / 2.0);
		
		return (Math.abs(player - valueA) < Math.abs(player - valueB));
	}
}