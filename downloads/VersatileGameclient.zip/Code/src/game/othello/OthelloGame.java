package game.othello;

import java.awt.Color;
import java.awt.Component;
import java.util.HashMap;

import nl.hanze.t23i.gamemodule.extern.AbstractGameModule;

/**
 * The game class of the game Othello.
 * This class holds all the game rules of this game.
 * This class also checks weither a move is legal.
 * @author Mart, Wim, Bas, Jurrian
 *
 */
public class OthelloGame extends AbstractGameModule {

	public static final String GAME_TYPE = Game.GAME_TYPE;
	
	public static final int PLAYER_ONE = 0;
	public static final int PLAYER_TWO = 1;
	
	private GameView gameView;
	protected String nextPlayer;
	private String moveDetails;
	private HashMap<String, Integer> playerResults;
	
	//protected int[][] board = new int[ 8 ][ 8 ];
	protected OthelloBoard board;
	public Color playerOneColor = Color.white;
	public Color playerTwoColor = Color.black;	
	
	public OthelloGame(String playerOne, String playerTwo) {
		super(playerOne, playerTwo);
		board = new OthelloBoard();
		board.initialize();
		moveDetails = null;
		playerResults = new HashMap<String, Integer>();
		gameView = new GameView(playerOne, playerTwo);
		gameView.update(board);
	}
	
	@Override
	public void doPlayerMove(String player, String move) throws IllegalStateException {
		super.doPlayerMove(player, move);
		
		if(!nextPlayer.equals(player)) {
			illegalPlayerMove(player, "Not player's turn");
			return;
		}
		
		String delimiter = ",";
		String[] coordinates_raw = move.split(delimiter);
		int x = Integer.parseInt(coordinates_raw[0]);
		int y = Integer.parseInt(coordinates_raw[1]);
		
		int playerInt = getPlayerInt(player);
		
		//if position is not empty.. It is an illegal move, same for out of bounds
		if(!board.isEmpty(x, y) || x < 0 || y < 0 || x >= OthelloBoard.WIDTH || y >= OthelloBoard.HEIGHT || !board.isValidMove(playerInt, x, y)){
			illegalPlayerMove(player, "Illegal move");
			return;
		}
		
		int flippedTiles = board.place(playerInt, x, y);
		
		if(!board.canPlayerMove(PLAYER_ONE) && !board.canPlayerMove(PLAYER_TWO)){
			
			int opp = getOtherPlayer(playerInt);
			
			matchStatus = MATCH_FINISHED;
			moveDetails = "Geen zetten meer mogelijk";
			
			int stonesPlayer = board.countPlayerStones(playerInt);
			int stonesOtherPlayer = board.countPlayerStones(opp);
			String oppStr = getOtherPlayer(player);
			if(stonesPlayer > stonesOtherPlayer){
				playerResults.put(player, PLAYER_WIN);
				playerResults.put(player + "Score", stonesPlayer);
				playerResults.put(oppStr, PLAYER_LOSS);
				playerResults.put(oppStr + "Score", stonesOtherPlayer);
			}else if(stonesOtherPlayer > stonesPlayer){
				playerResults.put(player, PLAYER_LOSS);
				playerResults.put(player + "Score", stonesPlayer);
				playerResults.put(getOtherPlayer(player), PLAYER_WIN);
				playerResults.put(oppStr + "Score", stonesOtherPlayer);
			}else{
				playerResults.put(player, PLAYER_DRAW);
				playerResults.put(player + "Score", stonesPlayer);
				playerResults.put(getOtherPlayer(player), PLAYER_DRAW);
				playerResults.put(oppStr + "Score", stonesOtherPlayer);
			}
			
		}else{
			//nothing else matters
			moveDetails = flippedTiles + " turned";
			changeTurns();
		}
		gameView.update(board);
		
	}

	/**
	 * Method to handle a illegal move.
	 * @param player
	 * @param reason
	 */
	public void illegalPlayerMove(String player, String reason) {
		matchStatus = MATCH_FINISHED;
		moveDetails = reason;
		String opp = getOtherPlayer(player);
		playerResults.put(player, PLAYER_LOSS);
		playerResults.put(player + "Score", board.countPlayerStones(getPlayerInt(player)));
		playerResults.put(opp, PLAYER_WIN);
		playerResults.put(opp + "Score", board.countPlayerStones(getPlayerInt(opp)));
	}
	
	@Override
	public String getMatchResultComment() throws IllegalStateException {
		super.getMatchResultComment();
		return moveDetails;
	}

	@Override
	public int getMatchStatus() {
		return matchStatus;
	}

	@Override
	public String getMoveDetails() throws IllegalStateException {
		super.getMoveDetails();
		if(moveDetails == null) {
			throw new IllegalStateException("No move has been done during this match");
		}
		return moveDetails;
	}

	@Override
	public String getPlayerToMove() throws IllegalStateException {
		super.getPlayerToMove();
		return nextPlayer;
	}

	@Override
	public int getPlayerResult(String player) throws IllegalStateException {
		super.getPlayerResult(player);
		return playerResults.get(player);
	}
	
	@Override
	public int getPlayerScore(String player) throws IllegalStateException {
		super.getPlayerResult(player);
		return playerResults.get(player + "Score");
	}

	@Override
	public String getTurnMessage() throws IllegalStateException {
		super.getTurnMessage();
		String message = null;
		if(moveDetails == null) {
			message = "Maak zoveel mogelijk stenen jouw kleur";
		} else {
			message = moveDetails;
		}
		return message;
	}

	@Override
	public Component getView() {
		return gameView;
	}

	@Override
	public void start() throws IllegalStateException {
		super.start();
		nextPlayer = playerOne;
	}
	
	private void changeTurns() {
		int otherPlayerInt = getPlayerInt(getOtherPlayer(nextPlayer));
		if(board.canPlayerMove(otherPlayerInt)){
			nextPlayer = getOtherPlayer(nextPlayer);
		}
	}
	
	/**
	 * get the int of the player
	 * @param player
	 * @return
	 */
	public int getPlayerInt(String player) {
		if(player.equals(playerOne)){
			return PLAYER_ONE;
		}else{
			return PLAYER_TWO;
		}
	}
	
	/**
	 * Get other player name.
	 * @param player
	 * @return String
	 */
	public String getOtherPlayer(String player) {
		return player.equals(playerOne) ? playerTwo : playerOne;
	}
	
	/**
	 * Method to get the other player int.
	 * @param player
	 * @return int
	 */
	public static int getOtherPlayer(int player) {
		return (player == PLAYER_ONE) ? PLAYER_TWO : PLAYER_ONE;
	}
	
	/**
	 * Getter for board.
	 * @return OthelloBoard board
	 */
	public OthelloBoard getBoard(){
		return board;
	}
}
