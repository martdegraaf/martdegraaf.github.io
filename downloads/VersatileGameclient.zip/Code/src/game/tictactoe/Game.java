package game.tictactoe;

/**
 * Game class that holds the GAME_TYPE of this game.
 * @author Mart, Wim, Bas, Jurrian
 *
 */
public class Game {

	public static final String GAME_TYPE = "TicTacToeGame";

}
