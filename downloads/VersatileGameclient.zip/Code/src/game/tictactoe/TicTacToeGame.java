package game.tictactoe;

import java.awt.Component;
import java.util.HashMap;

import nl.hanze.t23i.gamemodule.extern.AbstractGameModule;

/**
 * The game class of the game TicTacToe.
 * This class holds all the game rules of this game.
 * This class also checks weither a move is legal.
 * It also holds the game board.
 * @author Mart, Wim, Bas, Jurrian
 *
 */
public class TicTacToeGame extends AbstractGameModule {

	public static final String GAME_TYPE = Game.GAME_TYPE;
	
	public static final int PLAYER_ONE    = 0; 
	public static final int PLAYER_TWO    = 1; 
	public  static final int EMPTY        = 2;
	
	private GameView gameView;
	protected String nextPlayer;
	private String moveDetails;
	private HashMap<String, Integer> playerResults;
	
	protected int[][] board = new int[ 3 ][ 3 ];
	public static final char playerOneChar = 'X';
	public static final char playerTwoChar = 'O';	
	
	public TicTacToeGame(String playerOne, String playerTwo) {
		super(playerOne, playerTwo);
		
		moveDetails = null;
		playerResults = new HashMap<String, Integer>();
		gameView = new GameView(playerOne, playerTwo);
		clearBoard();
	}
	
	@Override
	public void doPlayerMove(String player, String move) throws IllegalStateException {
		super.doPlayerMove(player, move);
		
		if(!nextPlayer.equals(player)) {
			illegalPlayerMove(player, "It is not player's turn");
			return;
		}
		
		
		//Moves come as: "0,0" split them in int x and int y
		String[] coordinates;
		String delimiter = ",";
		coordinates = move.split(delimiter);
		int x = Integer.parseInt(coordinates[0]);
		int y = Integer.parseInt(coordinates[1]);
		
		//if position is not empty or it is an number out of one of the arrays.. It is an illegal move
		if(board[x][y] != EMPTY || 
				x < 0 || y < 0 ||
				x > board.length || y > board[0].length){
			illegalPlayerMove(player, "Illegal move");
			return;
		}
		if(player.equals(playerOne)){
			board[x][y] = PLAYER_ONE;
		}else{
			board[x][y] = PLAYER_TWO;
		}
		
		if(isAWin(board, getPlayerInt(player))){
			matchStatus = MATCH_FINISHED;
			moveDetails = "3 op een rij";
			//player wins
			playerResults.put(player, PLAYER_WIN);
			playerResults.put(otherPlayer(player), PLAYER_LOSS);
		}else if(boardIsFull(board)){
			matchStatus = MATCH_FINISHED;
			moveDetails = "Bord vol";
			//make it tie
			playerResults.put(player, PLAYER_DRAW);
			playerResults.put(otherPlayer(player), PLAYER_DRAW);
		}else{
			//nothing else matters
			moveDetails = "Gezet " + move;
			nextPlayer();
		}
		
		//update view
		gameView.updateField(fieldToString());			
	}
	
	/**
	 * Getter for player int.
	 * @param player
	 * @return
	 */
	public int getPlayerInt(String player) {
		if(player.equals(playerOne)){
			return PLAYER_ONE;
		}else{
			return PLAYER_TWO;
		}
	}

	/**
	 * Method to handle a illegal move.
	 * @param player
	 * @param reason
	 */
	private void illegalPlayerMove(String player, String reason) {
		matchStatus = MATCH_FINISHED;
		moveDetails = reason;
		playerResults.put(otherPlayer(player), PLAYER_WIN);
		playerResults.put(player, PLAYER_LOSS);
	}
	
	@Override
	public String getMatchResultComment() throws IllegalStateException {
		super.getMatchResultComment();
		
		return "Spel uitgespeeld";
	}

	@Override
	public int getMatchStatus() {
		return matchStatus;
	}

	@Override
	public String getMoveDetails() throws IllegalStateException {
		super.getMoveDetails();
		
		if(moveDetails == null) {
			throw new IllegalStateException("No move has been done during this match");
		}
		
		return moveDetails;
	}

	@Override
	public String getPlayerToMove() throws IllegalStateException {
		if(matchStatus != MATCH_FINISHED){super.getPlayerToMove();}
		
		return nextPlayer;
	}

	@Override
	public int getPlayerResult(String player) throws IllegalStateException {
		super.getPlayerResult(player);
		
		return playerResults.get(player);
	}
	
	@Override
	public int getPlayerScore(String player) throws IllegalStateException {
		super.getPlayerResult(player);
		
		return playerResults.get(player);
	}

	@Override
	public String getTurnMessage() throws IllegalStateException {
		super.getTurnMessage();
		
		String message = null;
		
		if(moveDetails == null) {
			message = "Leg 3 op een rij!";
		} else {
			message = moveDetails;
		}
		
		return message;
	}

	@Override
	public Component getView() {
		return gameView;
	}

	@Override
	public void start() throws IllegalStateException {
		super.start();
		
		nextPlayer = playerOne;
		clearBoard();
	}
	
	/**
	 * Method to set the nextPlayer.
	 */
	private void nextPlayer() {
		nextPlayer = otherPlayer(nextPlayer);
	}
	
	/**
	 * Method to get the other players name.
	 * @param player
	 * @return String
	 */
	protected String otherPlayer(String player) {
		return player.equals(playerOne) ? playerTwo : playerOne;
	}
	
	/**
	 * Get the other player
	 * @param player
	 * @return other player
	 */
	public static int getOtherPlayerInt(int player) {
		if(player == TicTacToeGame.PLAYER_ONE) return TicTacToeGame.PLAYER_TWO;
		return TicTacToeGame.PLAYER_ONE;
	}
	
	// Simple supporting routines
	private void clearBoard( )
	{
		for(int i = 0;i<board.length;i++){
			for(int j = 0;j<board[i].length;j++){
				board[i][j] = 2;
			}
		}
	}
	/**
	 * Checks if board is full return true
	 */
	public static boolean boardIsFull(int[][] board )
	{
		for(int i = 0;i<board.length;i++){
			for(int j = 0;j<board[i].length;j++){
				if(board[i][j] != PLAYER_ONE && board[i][j] != PLAYER_TWO){
					return false;
				}
			}
		}
		return true;
	}
	/**
	 * Returns true if side wins.
	 * @param side
	 * @return
	 */
	public static boolean isAWin(int[][] board, int player )
	{
		for(int i = 0; i < 3; i++) {
		    if(board[i][0] == player && board[i][1] == player && board[i][2] == player) return true; // Vertical
		    if(board[0][i] == player && board[1][i] == player && board[2][i] == player) return true; // Horizontal
		}
	    if(board[0][0] == player && board[1][1] == player && board[2][2] == player) return true; // Top left -> bottom right
	    if(board[2][0] == player && board[1][1] == player && board[0][2] == player) return true; // Top right -> bottom left
	    return false;
    }	
	
	/**
	 * Function to print board to simple text
	 * @return String
	 */
	public String toString()
	{
	    String print = "";
		for(int i = 0; i < board.length;i++){
	    	for(int j = 0; j< board[i].length; j++){
	    		if(board[i][j] == PLAYER_ONE){
	    			print += playerOneChar;
	    		}else if(board[i][j] == PLAYER_TWO){
	    			print += playerTwoChar;
	    		}else{
	    			print += "-";
	    		}
	    	}
	    	print += "\n";
	    }
		return print;   
	} 
	
	/**
	 * Function to print board to simple text
	 * @return String
	 */
	public String fieldToString()
	{
	    String print = " |012\n";
	    print += "-+---\n";
		for(int i = 0; i < board.length;i++){
			print += i+"|";
	    	for(int j = 0; j< board[i].length; j++){
	    		if(board[i][j] == PLAYER_ONE){
	    			print += playerOneChar;
	    		}else if(board[i][j] == PLAYER_TWO){
	    			print += playerTwoChar;
	    		}else{
	    			print += "-";
	    		}
	    	}
	    	print += "\n";
	    }
		return print;
	} 

}
