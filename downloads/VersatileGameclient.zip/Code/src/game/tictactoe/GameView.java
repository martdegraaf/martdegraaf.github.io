package game.tictactoe;

import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

/**
 * View class that holds the view of the game.
 * @author Mart, Wim, Bas, Jurrian
 *
 */
public class GameView extends JPanel {

	private static final long serialVersionUID = 0L;
	
	private JTextArea textArea;
	private JScrollPane scrollPane;
	
	public GameView(String playerOne, String playerTwo) {
		super(new GridLayout(2, 1));
		setVisible(true);
		
		textArea = new JTextArea(10, 20);
		//set font where all characters are equal length
		textArea.setFont(new Font("Courier", Font.PLAIN, 10));
		
		scrollPane = new JScrollPane(textArea);
		add(scrollPane);
		
		JPanel panel = new JPanel(new FlowLayout());
		panel.add(new JLabel("Player 1: " + playerOne));
		panel.add(new JLabel("Player 2: " + playerTwo));
		add(panel);
	}
	
	/**
	 * Method to add text to the field.
	 * @param text
	 */
	public void addText(String text) {
		textArea.append(text + "\n");
	}
	/**
	 * Method to update the TextField
	 * @param text
	 */
	public void updateField(String text) {
		textArea.setText(text);
		textArea.setDisabledTextColor(Color.gray);
	}

}
